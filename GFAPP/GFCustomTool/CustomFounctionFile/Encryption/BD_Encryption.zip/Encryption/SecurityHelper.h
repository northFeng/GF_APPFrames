//
//  SecurityHelper.h
//  baiduHi
//
//  Created by Wang Ping on 13-11-22.
//  Copyright (c) 2013年 Baidu. All rights reserved.
//
#import "HIIMSClient.h"
#import <Foundation/Foundation.h>

@interface SecurityHelper : NSObject

//字符串转MD5
+ (NSString *)MD5:(NSString *)str;
//inter 转 char
+( unsigned char *)integerToChares:(NSInteger)integer;
//十六进制字符串转char
+(unsigned char *)hexStringToChar:(NSString *)hex;
//字符比较
+(char)doCharXor:(char)a with:(char)b;
//char指针转十六进制字符串
+(NSString *)charesToHexString:(unsigned char *)sChares withLenght:(NSInteger)lenght;
//char数组转十六进制字符串
+(NSString *)scharesToHexString:(unsigned char [])sChares withLenght:(NSInteger)lenght;

// ASE CBC 加密解密
+ (NSString *)aesEncryptString:(NSString *)originString key:(NSString *)aesKey Iv:(NSString *)aesIv;
+ (NSString *)aesDecryptString:(NSString *)originString key:(NSString *)aesKey Iv:(NSString *)aesIv;

// ASE ECB 加密解密
+ (nullable NSData *)aesEcbEncryptData:(NSData *)utf8Data key:(NSString *)aesKey Iv:(NSString *)aesIv;
+ (nullable NSData *)aesEcbDecryptData:(NSData *)aesData key:(NSString *)aesKey Iv:(NSString *)aesIv;


///  ASE ECB NO Pading hicore解密之后的数据
/// @param decrypt 解密需要的key 需要用hicore再解一次
/// @param extinfo 待解密的内容
/// @param client  
+ (NSDictionary *)aesECBNoPaddingDectryWithDecryptKey:(NSString *_Nullable)decrypt
                                          withExtinfo:(NSString *_Nullable)extinfo
                                      withHIIMSClient:(HIIMSClient *_Nullable)client;

@end
