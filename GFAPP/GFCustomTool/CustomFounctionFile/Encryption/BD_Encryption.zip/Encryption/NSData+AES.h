//
//  NSData+AES.h
//  SAPIDemo
//
//  Created by zhoukeke on 13-5-9.
//  Custom by wangping
//

#import <Foundation/Foundation.h>
#import <CommonCrypto/CommonCrypto.h>

@interface NSData (AES)

- (NSData *)AES128Operation:(CCOperation)operation key:(NSString *)key iv:(NSString *)iv;
- (NSData *)AES128EncryptWithKey:(NSString *)key iv:(NSString *)iv;
- (NSData *)AES128DecryptWithKey:(NSString *)key iv:(NSString *)iv;
- (NSData *)AES128NoBase64Operation:(CCOperation)operation key:(NSString *)key iv:(NSString *)iv;
- (NSData *)AES128NoBase64EncryptWithKey:(NSString *)key iv:(NSString *)iv;
- (NSData *)AES128NoBase64DecryptWithKey:(NSString *)key iv:(NSString *)iv;
- (NSData *)AES128NoBase64EncryptWithCharKey:(char *)key charIv:(char *)iv;
- (NSData *)AES128NoBase64DecryptWithCharKey:(char *)key charIv:(char *)iv;

// CBC NO Padding
- (NSData *)AES128NoPaddingEncryptWithCharKey:(char *)key charIv:(char *)iv;
- (NSData *)AES128NoPaddingDecryptWithCharKey:(char *)key charIv:(char *)iv;

// CBC PKCS7Padding
- (NSData *)AES128CBCPKCS7PaddingEncryptWithKey:(const void *)key Iv:(const void *)iv;

// ECB NO Padding
- (NSData *)AES128ECBNoPaddingEncryptWithCharKey:(char *)key charIv:(char *)iv;
- (NSData *)AES128ECBNoPaddingDecryptWithCharKey:(char *)key charIv:(char *)iv;


// ECB kCCOptionPKCS7Padding
- (NSData *)AES128PKCS7PaddingEncryptWithKey:(NSString *)key;  //加密
- (NSData *)AES128PKCS7PaddingDecryptWithKey:(NSString *)key;  //解密

@end
