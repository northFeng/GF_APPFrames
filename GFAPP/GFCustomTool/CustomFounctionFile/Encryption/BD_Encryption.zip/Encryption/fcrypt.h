/**
 * @file
 * @brief fcrypt数据加密解密
 */

/** $Id: fcrypt.h,v 1.6 2009/07/23 08:47:20 scmpf Exp $
 *  crypt function.
 *      u_short checksum_short (const void *ptr, unsigned len);
 *      unsigned int checksum_int (const void *ptr, unsigned len);
 *
 *      fcrypt_t* fcrypt_create( const char* crypt_key );
 *      int fcrypt_destroy( fcrypt_t* pfc );
 *      int fcrypt_encode( fcrypt_t* pfc, const void* pdata, int datalen, void *pbuf, int buflen );
 *      int fcrypt_decode( fcrypt_t* pfc, const void* pdata, int datalen, void *pbuf, int buflen );
 *      int fcrypt_encode_hmac( fcrypt_t* pfc, const void* pdata,int datalen,void *pbuf,int buflen );
 *      int fcrypt_decode_hmac( fcrypt_t* pfc, const void* pdata, int datalen, void *pbuf, int buflen );
 *
 *      int fcrypt_id_2hstr( fcrypt_t* pfc, unsigned int id1, unsigned int id2, char* pstrbuf, int buflen );
 *      int fcrypt_hstr_2id( fcrypt_t* pfc, const char* phexstr, unsigned int *pid1, unsigned int *pid2 );
 *      int fcrypt_data_2hstr( fcrypt_t* pfc, void* pdata, int datalen, void* pstrbuf, int buflen );
 *      int fcrypt_hstr_2data( fcrypt_t* pfc, const char* phexstr, void* pdatabuf, int buflen );
 *
 *      int fcrypt_random( struct random_data *buf, int32_t *result );
 *      int fcrypt_srandom( unsigned int seed, struct random_data *buf );
 *
 *  以下系列函数使用static全局变量，不推荐使用
 *      int fcrypt_init( const char* crypt_key );
 *      int fcrypt_encode( const void* pdata, int datalen, void *pbuf, int buflen );
 *      int fcrypt_decode( const void* pdata, int datalen, void *pbuf, int buflen );
 *      int fcrypt_encode_hmac(const void* pdata,int datalen,void *pbuf,int buflen );
 *      int fcrypt_decode_hmac( const void* pdata, int datalen, void *pbuf, int buflen );
 *
 *      int fcrypt_id_2hstr( unsigned int id1, unsigned int id2, char* pstrbuf, int buflen );
 *      int fcrypt_hstr_2id( const char* phexstr, unsigned int *pid1, unsigned int *pid2 );
 *      int fcrypt_data_2hstr( void* pdata, int datalen, void* pstrbuf, int buflen );
 *      int fcrypt_hstr_2data( const char* phexstr, void* pdatabuf, int buflen );
 *
 *   pass strict unit-test, by zhaoxw.
 **/
#ifndef __FASTCRYPT_FUNCTION_HEAD_FILE__
#define __FASTCRYPT_FUNCTION_HEAD_FILE__

#include <stdlib.h>
#include <stddef.h>
#include <string.h>


//typedef __int32 int32_t;


struct random_data
{
	int32_t *fptr;              /* Front pointer.  */
	int32_t *rptr;              /* Rear pointer.  */
	int32_t *state;             /* Array of state values.  */
	int rand_type;              /* Type of random number generator.  */
	int rand_deg;               /* Degree of random number generator.  */
	int rand_sep;               /* Distance between front and rear.  */
	int32_t *end_ptr;           /* Pointer behind state table.  */
};

struct fcrypt_t;


/**
 *  创建fcrypt
 *
 *  @param[in]  crypt_key  做密钥的字符串
 *  @param[out]
 *  @return 成功返回fcrypt句柄，失败返回NULL
 */
fcrypt_t* fcrypt_create( const char* crypt_key);
int fcrypt_init( const char* crypt_key ) /*__attribute_deprecated__*/;


/**
 *  释放fcrypt
 *
 *  @param[in]  fcrypt句柄
 *  @param[out] 无
 *  @return 成功失败标志
 * - 0   成功
 * - -1  失败
 */
int fcrypt_destroy( fcrypt_t* pfc );


/**
 *  将数据加密
 *
 *  @param[in]  fcrypt句柄
 *  @param[in]  pdata    要加密的buf
 *  @param[in]  datalen  要加密的数据长度
 *  @param[in]  pbuf     存储加密后数据的buf
 *  @param[in]  buflen   存储buf的大小
 *  @param[out] pbuf     加密的数据
 *  @return 返回状态
 * - >0   成功,返回加密的数据长度
 * - -1   失败
 */
int fcrypt_encode( fcrypt_t* pfc, const void* pdata, int datalen, void *pbuf, int buflen );
int fcrypt_encode( const void* pdata, int datalen, void *pbuf, int buflen ) /*__attribute_deprecated__*/;


/**
 *  将数据解密
 *
 *  @param[in]  fcrypt句柄
 *  @param[in]  pdata    要解密的buf
 *  @param[in]  datalen  要解密的数据长度
 *  @param[in]  pbuf     存储解密后数据的buf
 *  @param[in]  buflen   存储buf的大小
 *  @param[out] pbuf     解密的数据
 *  @return 返回状态
 * - >0   成功,返回解密的数据长度
 * - -1   失败
 */
int fcrypt_decode( fcrypt_t* pfc, const void* pdata, int datalen, void *pbuf, int buflen );
int fcrypt_decode( const void* pdata, int datalen, void *pbuf, int buflen ) /*__attribute_deprecated__*/;


/**
 *  将数据+校验->加密, 多4个字节
 *
 *  @param[in]  fcrypt句柄
 *  @param[in]  pdata    要加密的buf
 *  @param[in]  datalen  要加密的数据长度
 *  @param[in]  pbuf     存储解加密数据的buf
 *  @param[in]  buflen   存储buf的大小
 *  @param[out] pbuf     加密的数据
 *  @return 返回状态
 * - >0   成功,返回加密的数据长度(含校验位长度+4)
 * - -1   失败,参数错误
 *  @note 要确保datalen+4<=buflen,得到的加密结果包含校验信息
 */
int fcrypt_encode_hmac( fcrypt_t* pfc, const void* pdata, int datalen, void *pbuf, int buflen );
int fcrypt_encode_hmac( const void* pdata, int datalen, void *pbuf, int buflen ) /*__attribute_deprecated__*/;



/**
 *  将包含校验信息的加密数据解密
 *
 *  @param[in]  fcrypt句柄
 *  @param[in]  pdata    要解密的buf
 *  @param[in]  datalen  要解密的数据长度
 *  @param[in]  pbuf     存储解密后数据的buf
 *  @param[in]  buflen   存储buf的大小
 *  @param[out] pbuf     解密的数据
 *  @return 返回状态
 * - >0   成功,返回解密的数据长度(不包含校验信息)
 * - -1   失败,参数错误
 * - -2   失败,校验错误
 *  @note 要确保datalen>=4 && datalen<=<buflen
 */
int fcrypt_decode_hmac( fcrypt_t* pfc, const void* pdata, int datalen, void *pbuf, int buflen );
int fcrypt_decode_hmac( const void* pdata, int datalen, void *pbuf, int buflen ) /*__attribute_deprecated__*/;




/**
 *  将id加密+校验和, 并以十六进制字符串组织
 *
 *  @param[in]  fcrypt句柄
 *  @param[in]  id1      要加密的id1
 *  @param[in]  id2      要加密的id2
 *  @param[in]  pstrbuf  存储加密后数据的buf
 *  @param[in]  buflen   存储buf的大小
 *  @param[out] pstrbuf  加密的数据
 *  @return 返回状态
 * - >0   成功
 * - <0   失败,由于buf长度不够
 *  @note buf大小最小为: 32个字节
 */
int fcrypt_id_2hstr( fcrypt_t* pfc, unsigned int id1, unsigned int id2, char* pstrbuf, int buflen );
int fcrypt_id_2hstr( unsigned int id1, unsigned int id2, char* pstrbuf, int buflen ) /*__attribute_deprecated__*/;


/**
 *  将十六进制字符串解码-->解密+校验数据. 获得原来的2个id
 *
 *  @param[in]  fcrypt句柄
 *  @param[in]  phexstr      要解密的数据
 *  @param[in]  pid1         id1存储的buf
 *  @param[in]  pid2         id2存储的buf
 *  @param[out] pid1         解密得到的id1
 *  @param[out] pid2         解密得到的id1
 *  @return 返回状态
 * - >=0   成功
 * - <0    校验错误
 */
int fcrypt_hstr_2id( fcrypt_t* pfc, const char* phexstr, unsigned int *pid1, unsigned int *pid2 );
int fcrypt_hstr_2id( const char* phexstr, unsigned int *pid1, unsigned int *pid2 ) /*__attribute_deprecated__*/;





/**
 *  将数据加密+校验, 输出为十六进制字符串
 *
 *  @param[in]  fcrypt句柄
 *  @param[in]  pdata      要加密的数据
 *  @param[in]  datalen    加密的数据长度
 *  @param[in]  pstrbuf    存储加密的buf
 *  @param[in]  buflen     buf的大小
 *  @param[out] pstrbuf    得到加密的数据
 *  @return 返回状态
 * - >=0   成功
 * - <0    数据长度太长, 或缓冲区长度太小
 *  @note 数据长度最大为1024个字节, 并且下面的条件需要得到保证：buflen >= (datalen*2+9)
 */
int fcrypt_data_2hstr( fcrypt_t* pfc, void* pdata, int datalen, void* pstrbuf, int buflen );
int fcrypt_data_2hstr( void* pdata, int datalen, void* pstrbuf, int buflen ) /*__attribute_deprecated__*/;




/**
 *  将十六进制字符串解码-->解密+校验数据. 获得原来数据
 *
 *  @param[in]  fcrypt句柄
 *  @param[in]  phexstr     要解密的数据
 *  @param[in]  pdatabuf    存储解密的buf
 *  @param[in]  buflen      存储解密的buf大小
 *  @param[out] pdatabuf    得到解密的数据
 *  @return 返回状态
 * - >=0   成功,解码出来的数据长度
 * - <0    解码/校验错误, 或字符串长度太长, 或缓冲区长度太小
 *  @note 字符串长度最大为2048, databuf必须大于 (strlen(phexstr)/2+4)
 */
int fcrypt_hstr_2data( fcrypt_t* pfc, const char* phexstr, void* pdatabuf, int buflen );
int fcrypt_hstr_2data( const char* phexstr, void* pdatabuf, int buflen ) /*__attribute_deprecated__*/;


/**
 *  随机数生成函数，取自glibc 2.3.4，主要供库内部使用
 *
 *  @param[in]  buf  生成随机数依赖的源数据
 *  @param[in]  result  存储生成的随机数
 *  @param[out]  buf  每次生成随机数后，buf中数据改变，成为下次生成随机数的源数据
 *  @param[out]  result  生成的随机数
 *  @return 成功失败标志
 * - 0  成功
 * - -1  失败
 *  @note 必须先调用fcrypt_srandom_r初始化；线程安全
 **/
int fcrypt_random( struct random_data *buf, int32_t *result );


/**
 *  随机数生成初始化函数，取自glibc 2.3.4，主要供库内部使用
 *
 *  @param [in]  seed  生成随机数生成算法所需源数据的种子
 *  @param [in]  buf  存储随机数生成算法需要的源数据
 *  @param [out]  buf  生成的随机数生成算法所需的源数据
 *  @return 成功失败标志
 * - 0  成功
 * - -1  失败
 **/
int fcrypt_srandom( unsigned int seed, struct random_data *buf );

void __fcrypt_init( int *praw_dest, const char* crypt_key );
#endif
