//
//  SecurityHelper.m
//  baiduHi
//
//  Created by Wang Ping on 13-11-22.
//  Copyright (c) 2013年 Baidu. All rights reserved.
//

#import "SecurityHelper.h"
#import <CommonCrypto/CommonDigest.h>
#import "NSData+AES.h"
#import "NSData+IMNET.h"

@implementation SecurityHelper


+( unsigned char *)integerToChares:(NSInteger)integer
{
    unsigned char * chares = ( unsigned char *)malloc(4);
    chares[0] = (unsigned  char)(integer & 0x00ff);
    chares[1] = (unsigned  char)(integer >> 8 & 0x00ff);
    chares[2] = (unsigned  char)(integer >> 16 & 0x00ff);
    chares[3] = (unsigned  char)(integer >> 24 & 0x00ff);
    return chares;
}

+(char)doCharXor:(char)a with:(char)b
{
    a^=b;
    return a;
}

+(unsigned char *)hexStringToChar:(NSString *)hex
{
    if (0 == hex.length) {
        return NULL;
    }
    NSUInteger len = [hex length]/2;
    unsigned char *result = malloc(len);
    for(int i=0;i<len;i++){
        int pos = i*2;
        unsigned char posa =  [self toChar:[hex substringWithRange:NSMakeRange(pos, 1)]];
        unsigned char posb =  [self toChar:[hex substringWithRange:NSMakeRange(pos+1, 1)]];
        result[i]=( posa <<4 | posb );
    }
    return result;
}

+(char)toChar:(NSString *)cstr
{
    NSRange range = [@"0123456789abcdef" rangeOfString:cstr.lowercaseString];
    char b = (char)(range.location);
    return b;
}

+ (NSString *)MD5:(NSString *)str{
    if (str.length == 0) {
        return nil;
    }
    const char *cStr = [str UTF8String];
	unsigned char result[CC_MD5_DIGEST_LENGTH];
	
	CC_MD5( cStr, (CC_LONG)strlen(cStr), result );
	
	return [[NSString
             stringWithFormat:@"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
             result[0], result[1],
             result[2], result[3],
             result[4], result[5],
             result[6], result[7],
             result[8], result[9],
             result[10], result[11],
             result[12], result[13],
             result[14], result[15]
             ] lowercaseString];
}

+(NSString *)charesToHexString:(unsigned char *)sChares withLenght:(NSInteger)lenght
{
    NSMutableString *hexStr = [[NSMutableString alloc]initWithCapacity:5];
    for(int i=0;i<lenght;i++){
        [hexStr appendString:[[NSString stringWithFormat:@"%02X",sChares[i]] uppercaseString]];
    }
    
    return [hexStr lowercaseString];
}

+(NSString *)scharesToHexString:(unsigned char [])sChares withLenght:(NSInteger)lenght
{
    NSMutableString *hexStr = [[NSMutableString alloc]initWithCapacity:5];
    for(int i=0;i<lenght;i++){
        [hexStr appendString:[[NSString stringWithFormat:@"%02X",sChares[i]] uppercaseString]];
    }
    
    return [hexStr lowercaseString];
}

#pragma mark - AES encrypt

// 加密
+ (NSString *)aesEncryptString:(NSString *)originString key:(NSString *)aesKey Iv:(NSString *)aesIv {
    if (originString.length == 0 ) {
        return nil;
    }
    
    NSData *utf8Data = [originString dataUsingEncoding:NSUTF8StringEncoding];
    char *charKey = (char *)[SecurityHelper hexStringToChar:aesKey];
    char *charIv = (char *)[SecurityHelper hexStringToChar:aesIv];
    
    NSMutableData *finalData = [[NSMutableData alloc] initWithData:utf8Data];
    int remainder = utf8Data.length % 16;
    if (remainder > 0) {
        int value = 16 - remainder;
        char bytes[value];
        for (int i = 0; i < value; i++) {
            bytes[i] = 0;
        }
        [finalData appendBytes:bytes length:value];
    }
    
    NSData *secASEData = [finalData AES128NoPaddingEncryptWithCharKey:charKey charIv:charIv];
    free(charKey);
    free(charIv);
    
    return [secASEData hexStringValue];
}

// 解密
+ (NSString *)aesDecryptString:(NSString *)originString key:(NSString *)aesKey Iv:(NSString *)aesIv {
    if (originString.length == 0 ) {
        return nil;
    }
    
    NSData *utf8ASEData = [self p_decodeFromHexidecimal:originString];
    char *charKey = (char *)[SecurityHelper hexStringToChar:aesKey];
    char *charIv = (char *)[SecurityHelper hexStringToChar:aesIv];
    
    NSData *originData = [utf8ASEData AES128NoPaddingDecryptWithCharKey:charKey charIv:charIv];
    free(charKey);
    free(charIv);
    /*
     If the data is not null-terminated, you should use -initWithData:encoding:
     
     NSString* newStr = [[NSString alloc] initWithData:theData encoding:NSUTF8StringEncoding];
     If the data is null-terminated, you should instead use -stringWithUTF8String: to avoid the extra \0 at the end.
     
     NSString* newStr = [NSString stringWithUTF8String:[theData bytes]];
     Swift variant:
     
     let newStr = NSString(data: data, encoding: NSUTF8StringEncoding)
     */
//    NSString *string =  [NSString stringWithUTF8String:[originData bytes]];
    NSString *string =  [[NSString alloc] initWithData:originData encoding:NSUTF8StringEncoding];
    NSString *nString = [[NSString alloc] initWithUTF8String:[string UTF8String]];
    
    return nString;
}

+ (NSData *)p_decodeFromHexidecimal:(NSString *)str {
    if (str.length == 0) {
        return nil;
    }
    NSString *command = [NSString stringWithString:str];
    command = [command stringByReplacingOccurrencesOfString:@" " withString:@""];
    NSMutableData *commandToSend = [[NSMutableData data] init];
    unsigned char whole_byte;
    char byte_chars[3] = {'\0','\0','\0'};
    int i;
    for (i=0; i < [command length]/2; i++) {
        byte_chars[0] = [command characterAtIndex:i*2];
        byte_chars[1] = [command characterAtIndex:i*2+1];
        whole_byte = strtol(byte_chars, NULL, 16);
        [commandToSend appendBytes:&whole_byte length:1];
    }
    return commandToSend;
}

// -----------------------------------------------------------------------

// ASE ECB 加密解密
+ (NSData *)aesEcbEncryptData:(NSData *)utf8Data key:(NSString *)aesKey Iv:(NSString *)aesIv {
    if (utf8Data.length == 0 ) {
        return nil;
    }
    
//    NSData *utf8Data = [originString dataUsingEncoding:NSUTF8StringEncoding];
    char *charKey = (char *)[SecurityHelper hexStringToChar:aesKey];
    char *charIv = (char *)[SecurityHelper hexStringToChar:aesIv];
    
    NSMutableData *finalData = [[NSMutableData alloc] initWithData:utf8Data];
    int remainder = utf8Data.length % 16;
    if (remainder > 0) {
        int value = 16 - (utf8Data.length % 16);
        char bytes[value];
        for (int i = 0; i < value; i++) {
            bytes[i] = 0;
        }
        [finalData appendBytes:bytes length:value];
    }
    
    NSData *secASEData = [finalData AES128ECBNoPaddingEncryptWithCharKey:charKey charIv:charIv];
    free(charKey);
    free(charIv);
    
    return secASEData;
}

+ (NSData *)aesEcbDecryptData:(NSData *)aesData key:(NSString *)aesKey Iv:(NSString *)aesIv {
    if (aesData.length == 0 ) {
        return nil;
    }
    NSString *hexString = [aesData hexStringValue];
    NSData *utf8ASEData = [self p_decodeFromHexidecimal:hexString];
    char *charKey = (char *)[SecurityHelper hexStringToChar:aesKey];
    char *charIv = (char *)[SecurityHelper hexStringToChar:aesIv];
    
    NSData *originData = [utf8ASEData AES128ECBNoPaddingDecryptWithCharKey:charKey charIv:charIv];
    if (!originData) {
        return nil;
    }
    
    if (charKey != NULL) {
        free(charKey);
    }
    
    if (charIv != NULL) {
        free(charIv);
    }
    
    NSString *originString = [[NSString alloc] initWithUTF8String:[originData bytes]];
    return [originString dataUsingEncoding:NSUTF8StringEncoding];
}

+ (NSDictionary *)aesECBNoPaddingDectryWithDecryptKey:(NSString *)decrypt
                                          withExtinfo:(NSString *)extinfo
                                         withHIIMSClient:(HIIMSClient *)client {
    NSData *encryptAesKeyData = [[NSData alloc] initWithBase64EncodedString:decrypt options:NSDataBase64DecodingIgnoreUnknownCharacters];
    NSData *decryptAesKeyData = [client baiduContactsKey:encryptAesKeyData];
    // 数据解密
    NSData *encryptedData = [[NSData alloc] initWithBase64EncodedString:extinfo options:NSDataBase64DecodingIgnoreUnknownCharacters];
    NSData *decryptedInfoData;
    if (decryptAesKeyData && encryptedData) {
        char *charKey = (char *)[decryptAesKeyData bytes];
        decryptedInfoData = [encryptedData AES128ECBNoPaddingDecryptWithCharKey:charKey charIv:nil];
    }
    NSString *decryString;
    if (decryptedInfoData) {
        decryString = [[NSString alloc] initWithData:decryptedInfoData encoding:NSUTF8StringEncoding];
        decryString = [decryString stringByTrimmingCharactersInSet:[NSCharacterSet controlCharacterSet]];
    };
    
    if (decryString) {
        NSData *jsonData = [decryString dataUsingEncoding:NSUTF8StringEncoding];
        NSError *err;
        if (jsonData) {
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:jsonData
                                                                options:NSJSONReadingMutableContainers
                                                                  error:&err];
            return dic;
        }
    }
    return [[NSDictionary alloc] init];
}

@end
