#import <Foundation/Foundation.h>

@interface NSData (IMNET)

- (NSString *)md5;
- (NSData *)md5Digest;

- (NSString *)hexStringValue;

- (NSString *)base64Encoded;
- (NSData *)base64Decoded;

//取data中的一部分作为MD5的计算值
- (NSString *)fingerprint;
@end
