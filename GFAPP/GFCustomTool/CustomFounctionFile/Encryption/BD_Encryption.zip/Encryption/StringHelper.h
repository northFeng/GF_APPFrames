//
//  StringHelper.h

//  
//
//

#import <Foundation/Foundation.h>
typedef enum stringError{
  EStringIllgerType_None,
  EStringIllgerType_Length_Null,
  EStringIllgerType_Length_Invalid,
  EStringIllgerType_Format_error
} EStringIllgerType;
 
@interface StringHelper : NSObject {

}
+ (BOOL)stringIsEmpty:(NSString *)str;

+ (NSString *)stringOrEmpty:(NSString *)str;

+ (NSUInteger)chineseStringLen:(NSString *)str;

+ (NSString *)cutString:(NSString *)str length:(NSUInteger)length;

+ (NSString *)MD5:(NSString *)str;

+ (NSString *)encodeBase64:(NSString *)str;

+ (NSString *)decodeBase64:(NSString *)str;

+ (NSString *)stringByDecodingURLParamsFormat:(NSString *)str;

+ (NSString *)stringByEncodingURLParamsFormat:(NSString *)str;

+ (NSString *)encodeString:(NSString *)string;

+ (EStringIllgerType)isIllegalPassport:(NSString *) srcString isPassword:(BOOL) bPassword;

+ (BOOL)isEmailFormat:(NSString *) srcString;

+ (BOOL)versionCompare:(NSString *)localVersion serverVersion:(NSString *)serverVersion;

+ (NSDate *) convertDateFromString:(NSString*)str withFormat:(NSDateFormatter *)format;

+ (NSString *)stringByDecodingXMLEntities:(NSString *)str;

+ (NSString *)stringByEncodingXMLEntities:(NSString *)str;

+ (NSString *)formatValidatePhoneNumber:(NSString *)str;

//处理无效UTF8字符
+ (NSString *)cleanUTF8WithBytes:(const void *)bytes length:(NSUInteger)len;

/**
 *  使用系统API分词
 *
 *  @param text 目标text
 *
 *  @return 分词的词组
 */
+ (void)stringTokenizerWithText:(NSString *)text withCallback:(BDEXTLDataResultCallback) callback;


/**
 是否可以分词

 @param text
 @return 
 */
+ (BOOL)canTokenizerWithText:(NSString *)text;

@end
