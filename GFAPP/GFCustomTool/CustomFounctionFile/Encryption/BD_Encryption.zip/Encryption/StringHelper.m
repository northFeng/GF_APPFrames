//
//  StringHelper.m
//

#import "StringHelper.h"
#import "GTMBase64.h"
#include "iconv.h"
#import <CommonCrypto/CommonDigest.h>
#import "BDUILanguageManager.h"

@implementation StringHelper

+ (BOOL)stringIsEmpty:(NSString *)str{
  BOOL ret=NO;
	if(str==nil){
		ret=YES;
	}else{
		NSString * temp=[str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
		if([temp length]<1){
			ret=YES;
		}
	}
	return ret;
}

+ (NSString *)stringOrEmpty:(NSString *)str{
  return (str == nil ? @"" : str);
}

+ (NSUInteger)chineseStringLen:(NSString *)str{
  int newLength=0;
  if(str!=nil){
    int i=0;
		for(i=0;i<[str length];++i){
			unichar c=[str characterAtIndex:i];
			if(isalnum(c) || ' '==c){
        newLength+=1;
			}else{
        newLength+=2;
			}
		}
	}
  return newLength;
}

+ (NSString *)cutString:(NSString *)str length:(NSUInteger)length {
  NSString* ret=str;
	if(str!=nil){
		assert(length>0);
		//const int twiceLength=length*2;
		int newLength=0;
		int i=0;
		int lastIndex=0;
		for(i=0;i<length && i<[str length];++i){
			unichar c=[str characterAtIndex:i];
			if(isalnum(c) || ' '==c){
				//英文算半个
				if(newLength+1<=length){
					newLength+=1;
				}else{
					break;
				}
			}else{
				if(newLength+2<=length){
					newLength+=2;
				}else{
					break;
				}
			}
			++lastIndex;
		}
		ret=[str substringToIndex:lastIndex];
		assert(ret!=nil);
	}
	return ret;
}

+ (NSString *)MD5:(NSString *)str{
    if (str.length <= 0) {
        return nil;
    }
    const char *cStr = [str UTF8String];
	unsigned char result[CC_MD5_DIGEST_LENGTH];
	
	CC_MD5(cStr, (CC_LONG)strlen(cStr), result);
	
	return [[NSString
           stringWithFormat:@"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
           result[0], result[1],
           result[2], result[3],
           result[4], result[5],
           result[6], result[7],
           result[8], result[9],
           result[10], result[11],
           result[12], result[13],
           result[14], result[15]
           ] lowercaseString];
}

+ (NSString *)encodeBase64:(NSString *)str{
  NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
  //转换到base64
  data = [GTMBase64 encodeData:data];
  return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

+ (NSString *)decodeBase64:(NSString *)str{
  NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:YES];
  //base64解码
  data = [GTMBase64 decodeData:data];
  return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

+ (NSString *)stringByDecodingURLParamsFormat:(NSString *)str {
    // 关于URL中带空格的问题 https://blog.csdn.net/dyyshb/article/details/82346699
    NSString *result = [str stringByReplacingOccurrencesOfString:@"+" withString:@" "];
    result = [result stringByRemovingPercentEncoding];
    return result;
}

+ (NSString *)stringByEncodingURLParamsFormat:(NSString *)str {
  NSString *resultStr = str;
  
  CFStringRef originalString = (__bridge CFStringRef) str;
  CFStringRef leaveUnescaped = CFSTR(" ");
  CFStringRef forceEscaped = CFSTR("!*'();:@&=+$,/?%#[]");
  
  CFStringRef escapedStr;
  escapedStr = CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                       originalString,
                                                       leaveUnescaped, 
                                                       forceEscaped,
                                                       kCFStringEncodingUTF8);
  
  if( escapedStr )
  {
    NSMutableString *mutableStr = [NSMutableString stringWithString:(__bridge NSString *)escapedStr];
    CFRelease(escapedStr);
    
    // replace spaces with plusses
    [mutableStr replaceOccurrencesOfString:@" "
                                withString:@"%20"
                                   options:0
                                     range:NSMakeRange(0, [mutableStr length])];
    resultStr = mutableStr;
  }
  return resultStr;
}

+ (EStringIllgerType)isIllegalPassport:(NSString *) srcString isPassword:(BOOL) bPassword{
  NSUInteger srcLenght = [srcString length];
  if (0 == srcLenght) {
    return EStringIllgerType_Length_Null;
  }
  
  if (srcLenght > 14 ) {
    return EStringIllgerType_Length_Invalid;
  }

  if (bPassword && srcLenght < 6 ) {
    return EStringIllgerType_Length_Invalid;
  }
  
  int strBytes = 0;
  for (int i = 0; i < srcLenght; i++) {
    if (strBytes > 14 ) {
      return EStringIllgerType_Length_Invalid;
    }

    unichar c = [srcString characterAtIndex:i];
    if (c >= 0x4e00 && c<= 0x9fbf){
      if (bPassword) {
        return EStringIllgerType_Format_error;
      }
      strBytes += 2;
    }else if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z')
               || (c >= 'A' && c <= 'Z') || (c == '_')){
      strBytes += 1;
    }else{
      return EStringIllgerType_Format_error;
    }
  }
  
  if (strBytes > 14 ) {
    return EStringIllgerType_Length_Invalid;
  }

  if (bPassword && srcLenght < 6 ) {
    return EStringIllgerType_Length_Invalid;
  }
  
  return EStringIllgerType_None;
}

+ (BOOL)isEmailFormat:(NSString *) srcString{
    NSString *emailCheck = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",emailCheck];
    return [emailTest evaluateWithObject:srcString];
}

+ (BOOL)versionCompare:(NSString *)localVersion serverVersion:(NSString *)serverVersion
{
  return [localVersion compare:serverVersion options:NSNumericSearch] != NSOrderedAscending;
}

+ (NSDate *) convertDateFromString:(NSString*)str withFormat:(NSDateFormatter *)format{
    NSDate *date=[format dateFromString:str];
    return date;
}


+ (NSString *)stringByDecodingXMLEntities:(NSString *)str{
    NSUInteger myLength = [str length];
    NSUInteger ampIndex = [str rangeOfString:@"&" options:NSLiteralSearch].location;
    
    // Short-circuit if there are no ampersands.
    if (ampIndex == NSNotFound) {
        return str;
    }
    // Make result string with some extra capacity.
    
    NSMutableString *result = [NSMutableString stringWithCapacity:(myLength * 1.25)];
    
    
    // First iteration doesn't need to scan to & since we did that already, but for code simplicity's sake we'll do it again with the scanner.
    NSScanner *scanner = [NSScanner scannerWithString:str];
    
    [scanner setCharactersToBeSkipped:nil];
    
    NSCharacterSet *boundaryCharacterSet = [NSCharacterSet characterSetWithCharactersInString:@" \t\n\r;"];
    
    do {
        // Scan up to the next entity or the end of the string.
        NSString *nonEntityString;
        if ([scanner scanUpToString:@"&" intoString:&nonEntityString]) {
            [result appendString:nonEntityString];
        }
        if ([scanner isAtEnd]) {
            goto finish;
        }
        // Scan either a HTML or numeric character entity reference.
        if ([scanner scanString:@"&amp;" intoString:NULL])
            [result appendString:@"&"];
        else if ([scanner scanString:@"&apos;" intoString:NULL])
            [result appendString:@"'"];
        else if ([scanner scanString:@"&quot;" intoString:NULL])
            [result appendString:@"\""];
        else if ([scanner scanString:@"&lt;" intoString:NULL])
            [result appendString:@"<"];
        else if ([scanner scanString:@"&gt;" intoString:NULL])
            [result appendString:@">"];
        else if ([scanner scanString:@"&#x2F;" intoString:NULL])
            [result appendString:@"/"];
        else if ([scanner scanString:@"&#" intoString:NULL]) {
            BOOL gotNumber;
            unsigned charCode;
            NSString *xForHex = @"";
            
            // Is it hex or decimal?
            if ([scanner scanString:@"x" intoString:&xForHex]) {
                gotNumber = [scanner scanHexInt:&charCode];
            }
            else {
                gotNumber = [scanner scanInt:(int*)&charCode];
            }
            
            if (gotNumber) {
                [result appendFormat:@"%u", charCode];
                
                [scanner scanString:@";" intoString:NULL];
            }
            else {
                NSString *unknownEntity = @"";
                
                [scanner scanUpToCharactersFromSet:boundaryCharacterSet intoString:&unknownEntity];
                
                
                [result appendFormat:@"&#%@%@", xForHex, unknownEntity];
                
                //[scanner scanUpToString:@";" intoString:&unknownEntity];
                //[result appendFormat:@"&#%@%@;", xForHex, unknownEntity];
//                HILogError(HILogContextNormal, @"Expected numeric character entity but got &#%@%@;", xForHex, unknownEntity);
                
            }
            
        }
        else {
            NSString *amp;
            
            [scanner scanString:@"&" intoString:&amp];      //an isolated & symbol
            [result appendString:amp];
            
            /*
             NSString *unknownEntity = @"";
             [scanner scanUpToString:@";" intoString:&unknownEntity];
             NSString *semicolon = @"";
             [scanner scanString:@";" intoString:&semicolon];
             [result appendFormat:@"%@%@", unknownEntity, semicolon];
             HILogError(HILogContextNormal, @"Unsupported XML character entity %@%@", unknownEntity, semicolon);
             */
        }
        
    }
    while (![scanner isAtEnd]);
    
finish:
    return result;
}

+ (NSString *)stringByEncodingXMLEntities:(NSString *)str{
    if (nil == str || str.length == 0) {
        return @"";
    }
    
    NSMutableString *result = [NSMutableString stringWithString:str];
    [result replaceOccurrencesOfString:@"&" withString:@"&amp;" options:NSLiteralSearch range:NSMakeRange(0, result.length)];
    [result replaceOccurrencesOfString:@"'" withString:@"&apos;" options:NSLiteralSearch range:NSMakeRange(0, result.length)];
    [result replaceOccurrencesOfString:@"\"" withString:@"&quot;" options:NSLiteralSearch range:NSMakeRange(0, result.length)];
    [result replaceOccurrencesOfString:@"<" withString:@"&lt;" options:NSLiteralSearch range:NSMakeRange(0, result.length)];
    [result replaceOccurrencesOfString:@">" withString:@"&gt;" options:NSLiteralSearch range:NSMakeRange(0, result.length)];
    [result replaceOccurrencesOfString:@"\n" withString:@"<br/>" options:NSLiteralSearch range:NSMakeRange(0, result.length)];
    return result;
}

+ (NSString *)formatValidatePhoneNumber:(NSString *)str{
    if(nil == str ||str.length ==0 )
        return @"";
    
    NSMutableString *result = [NSMutableString stringWithString:str];
//    [result replaceOccurrencesOfString:@"-" withString:@"" options:NSLiteralSearch range:NSMakeRange(0,result.length)];
//    [result replaceOccurrencesOfString:@" " withString:@"" options:NSLiteralSearch range:NSMakeRange(0,result.length)];
    [result replaceOccurrencesOfString:@"＋" withString:@"+" options:NSLiteralSearch range:NSMakeRange(0,result.length)];
    
//    NSCharacterSet *setToRemove = [[ NSCharacterSet characterSetWithCharactersInString:@"0123456789 "] invertedSet ];
//    NSString *result = [[str componentsSeparatedByCharactersInSet:setToRemove] componentsJoinedByString:@""];
    
//    NSString *result = [str stringByReplacingOccurrencesOfString:@"[^0-9]"
//                                                            withString:@""
//                                                               options:NSRegularExpressionSearch
//                                                                 range:NSMakeRange(0, [str length])];
    return result;
}


+ (NSString *)encodeString:(NSString *)string
{
    if (!string || 0 == string.length) {
        return @"";
    }
    
    NSString *encodedString = (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                                                                    (CFStringRef)string,
                                                                                                    (CFStringRef)@"!$&'()*+,-./:;=?@_~%#[]",
                                                                                                    NULL,
                                                                                                    kCFStringEncodingUTF8));
    
    return encodedString;
}

//处理无效UTF8字符
+ (NSString *)cleanUTF8WithBytes:(const void *)bytes length:(NSUInteger)len{
    iconv_t cd = iconv_open("UTF-8", "UTF-8"); // convert to UTF-8 from UTF-8
    int one = 1;
    iconvctl(cd, ICONV_SET_DISCARD_ILSEQ, &one); // discard invalid characters
    
    size_t inbytesleft, outbytesleft;
    inbytesleft = outbytesleft = len;
    char *inbuf = (char *)bytes;
    char *outbuf = malloc(sizeof(char) * len);
    char *outptr = outbuf;
    if (iconv(cd, &inbuf, &inbytesleft, &outptr, &outbytesleft)
        == (size_t)-1) {
        NSLog(@"this should not happen, seriously");
        return nil;
    }
    
    NSString *result = [[NSString alloc] initWithBytes:outbuf
                                                length:(len - outbytesleft)
                                              encoding:NSUTF8StringEncoding];
    iconv_close(cd);
    free(outbuf);
    return result;
}

+ (BOOL)_isValidToken:(NSString *)t{
    if ([t isEqualToString:@" "] ||
        [t isEqualToString:@"\r\n"] ||
        [t isEqualToString:@"\n"] ||
        [t isEqualToString:@"\r"]) {
        return NO;
    }
    return YES;
}

+ (BOOL)canTokenizerWithText:(NSString *)text{
    CFStringTokenizerRef ref = CFStringTokenizerCreate(NULL,  (__bridge CFStringRef)text, CFRangeMake(0, text.length),kCFStringTokenizerUnitWord,NULL);
    //查找下一个分词
    CFStringTokenizerAdvanceToNextToken(ref);
    //获取range
    CFRange range = CFStringTokenizerGetCurrentTokenRange(ref);
    NSString *keyWord;
    BOOL hasFound = NO;
    while (range.length > 0 && !hasFound){
        //截取分词
        keyWord = [text substringWithRange:NSMakeRange(range.location, range.length)];
        if ([self _isValidToken:keyWord]) {
            hasFound = YES;
        } else {
            //查找下一个分词
            CFStringTokenizerAdvanceToNextToken(ref);
            //获取range
            range = CFStringTokenizerGetCurrentTokenRange(ref);
        }
    }
    CFRelease(ref);
    if (hasFound) {
        return YES;
    } else {
        return NO;
    }
}

+ (void)stringTokenizerWithText:(NSString *)text withCallback:(BDEXTLDataResultCallback) callback
{
    bd_dispatch_global_default_async(^{
        NSMutableArray *keyWords=[NSMutableArray array];
        //创建分词器
        CFStringTokenizerRef ref = CFStringTokenizerCreate(NULL,  (__bridge CFStringRef)text, CFRangeMake(0, text.length),kCFStringTokenizerUnitWordBoundary,NULL);
        //查找下一个分词
        CFStringTokenizerAdvanceToNextToken(ref);
        //获取range
        CFRange range = CFStringTokenizerGetCurrentTokenRange(ref);
        NSString *keyWord;
        while (range.length>0){
            //截取分词
            keyWord = [text substringWithRange:NSMakeRange(range.location, range.length)];
            //去除空格
            if ([self _isValidToken:keyWord]) {
                [keyWords addObject:keyWord];
            }
            //查找下一个分词
            CFStringTokenizerAdvanceToNextToken(ref);
            //获取range
            range = CFStringTokenizerGetCurrentTokenRange(ref);
        }
        //释放资源
        CFRelease(ref);
        if (callback) {
            callback(keyWords);
        }
    });
    
}

@end
