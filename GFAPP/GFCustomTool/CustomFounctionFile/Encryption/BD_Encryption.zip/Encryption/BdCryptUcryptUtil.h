//
//  BdCryptUcryptUtil.h
//  baiduHi
//
//  Created by Wang Ping on 13-8-20.
//  Copyright (c) 2013年 Baidu. All rights reserved.
//

#import <Foundation/Foundation.h>

#define CC_SHA256_DIGEST_LENGTH   20

@interface BdCryptUcryptUtil : NSObject

+ (NSString *)fileSha256WithFileURL: (NSURL *)url error:(NSError **)error;

+ (NSString *)fcryptIdToString:(long long)uid withKey:(NSString *)key;

+ (NSNumber *)fcryptStringToId:(NSString *)fcryptStr withKey:(NSString *)key;

+ (NSString *)hash_hmacToStringWithString:(NSString *)dataString key:(NSString *)key;

+ (NSString *)sha256WithString:(NSString *)string;

+ (NSString *)stringByEncodingURLFormat:(NSString*)key;

+ (NSNumber *)decodeUidToNumber:(NSString *)encode;

+ (NSString *)encodeUidToSign:(long long)uid withUserName:(NSString*)username;

//+ (NSString *)RSAEncryptContent:(NSString *)content publicKey:(NSString *)publicKey;

@end
