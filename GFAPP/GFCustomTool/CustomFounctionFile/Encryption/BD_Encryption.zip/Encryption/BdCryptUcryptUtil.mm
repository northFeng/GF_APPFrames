//
//  BdCryptUcryptUtil.m
//  baiduHi
//
//  Created by Wang Ping on 13-8-20.
//  Copyright (c) 2013年 Baidu. All rights reserved.
//

#import "BdCryptUcryptUtil.h"
#import "fcrypt.h"
#import "ucrypt.h"
#import <CommonCrypto/CommonHMAC.h>
#import <CommonCrypto/CommonCryptor.h>
#import <CommonCrypto/CommonDigest.h>

@implementation BdCryptUcryptUtil


#pragma mark --
#pragma mark Util tool

+ (NSString *)fileSha256WithFileURL: (NSURL *)url error:(NSError **)error {
    const NSUInteger kChunkSize = 1024 * 1024;
    NSFileHandle *handle = [NSFileHandle fileHandleForReadingFromURL:url error:error];
    if (!handle) {
        return nil;
    }
    
    CC_SHA256_CTX sha256;
    CC_SHA256_Init(&sha256);
    
    BOOL done = NO;
    while (!done) {
        @autoreleasepool {
            NSData *fileData = [handle readDataOfLength:kChunkSize];
            CC_SHA256_Update(&sha256, [fileData bytes], (CC_LONG)[fileData length]);
            if ([fileData length] == 0) {
                done = YES;
            }
        }
    }
    
    unsigned char digest[CC_SHA256_DIGEST_LENGTH];
    CC_SHA256_Final(digest, &sha256);
    
    NSData *data = [NSData dataWithBytes:digest length:CC_SHA256_DIGEST_LENGTH];
    
    NSString *hash = [data description];
    hash = [hash stringByReplacingOccurrencesOfString:@" " withString:@""];
    hash = [hash stringByReplacingOccurrencesOfString:@"<" withString:@""];
    hash = [hash stringByReplacingOccurrencesOfString:@">" withString:@""];
    return hash;
}

+ (NSString *)sha256WithString:(NSString *)string {
    const char *s = [string cStringUsingEncoding:NSASCIIStringEncoding];
    NSData *keyData = [NSData dataWithBytes:s length:strlen(s)];
    
    uint8_t digest[CC_SHA256_DIGEST_LENGTH] = {0};
    CC_SHA256(keyData.bytes, (CC_LONG)keyData.length, digest);
    NSData *out = [NSData dataWithBytes:digest length:CC_SHA256_DIGEST_LENGTH];
    NSString *hash = [out description];
    hash = [hash stringByReplacingOccurrencesOfString:@" " withString:@""];
    hash = [hash stringByReplacingOccurrencesOfString:@"<" withString:@""];
    hash = [hash stringByReplacingOccurrencesOfString:@">" withString:@""];
    
    //兼容iOS 13.1.3 13.5.1系统生成sha256的格式问题
    NSString *prefix = @"{length=32,bytes=";
    if ([hash hasPrefix:prefix]) {
        hash = [hash substringWithRange:NSMakeRange(prefix.length, hash.length - prefix.length - 1)];
    }
    return hash;
}

+ (NSString *)fcryptIdToString:(long long)uid withKey:(NSString *)key{
    struct fcrypt_t *cryptkey = fcrypt_create([key UTF8String]);
    char buffer[1024] = {0};
    fcrypt_id_2hstr(cryptkey, (u_int)uid, 100, buffer, 1024);
    NSString *fcryptStr = [NSString stringWithFormat:@"%s",buffer];
    return fcryptStr;
}

+ (NSNumber *)fcryptStringToId:(NSString *)fcryptStr withKey:(NSString *)key{
    struct fcrypt_t *cryptkey = fcrypt_create([key UTF8String]);
    unsigned int userId = 0;
    unsigned int magic_num =0;
    fcrypt_hstr_2id(cryptkey, [fcryptStr UTF8String], &userId, &magic_num);
    NSNumber *uid = [NSNumber numberWithInt:userId];
    return uid;
}

+ (NSString *)hash_hmacToStringWithString:(NSString *)dataString key:(NSString *)key
{
    if (!(dataString && key)) {
        return @"";
    }
    const char *cKey  = [key cStringUsingEncoding:NSASCIIStringEncoding];
    const char *cData = [dataString cStringUsingEncoding:NSASCIIStringEncoding];
    unsigned char cHMAC[CC_SHA256_DIGEST_LENGTH];
    CCHmac(kCCHmacAlgSHA256, cKey, strlen(cKey), cData, strlen(cData), cHMAC);
    NSData *HMACData = [NSData dataWithBytes:cHMAC length:sizeof(cHMAC)];
    const unsigned char *buffer = (const unsigned char *)[HMACData bytes];
    NSMutableString *HMAC = [NSMutableString stringWithCapacity:HMACData.length * 2];
    for (int i = 0; i < HMACData.length; ++i){
        [HMAC appendFormat:@"%02x", buffer[i]];
    }
    return [HMAC uppercaseString];
}

// TODO: 确认是否需要
+ (NSString *)stringByEncodingURLFormat:(NSString*)key{
    
    NSString *encodedString = (__bridge NSString *)CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,(CFStringRef)key, nil, (CFStringRef) @"!$&'()*+,-./:;=?@_~%#[]", kCFStringEncodingUTF8);
    return encodedString;
}

#pragma mark --
#pragma mark Util tool
+ (NSNumber *)decodeUidToNumber:(NSString *)encode{
    unsigned int userid = 0;
    char username[1024] = {0};
    if( user_url_decode([encode UTF8String],userid,username,1024)>0){
        return [NSNumber numberWithInt:userid];
    }
    return nil;
}

#pragma mark --
#pragma mark Util tool
+ (NSString *)encodeUidToSign:(long long)uid withUserName:(NSString*)username{
    char sign[200];
    if( user_url_encode((u_int)uid,[username UTF8String],sign,sizeof(sign))>0){
        return [NSString stringWithUTF8String: sign];
    }
    return nil;
}

//#pragma mark --
//#pragma mark RSA
//
//+ (NSString *)RSAEncryptContent:(NSString *)content publicKey:(NSString *)publicKey {
//    // pubkey
//    const char *pubkey = [publicKey UTF8String];
//    
//    // input
//    NSUInteger inputLength  = [content length];
//    const char *input = [content UTF8String];
//    
//    // output
//    NSInteger flen = rsaSize((char *)pubkey);
//    char *outData = (char*)malloc(flen);
//    bzero(outData, flen);
//    
//    // encrypt
//    int status = rsaEncrypt((char *)pubkey, (char *)input, (int)inputLength, outData);
//    if (status) {
//        NSData *returnData = [NSData dataWithBytes:outData length:status];
//        free(outData);
//        outData = NULL;
//        
//        returnData = [returnData base64EncodedDataWithOptions:0];
//        NSString *ret = [[NSString alloc] initWithData:returnData encoding:NSUTF8StringEncoding];
//        return ret;
//    }
//    
//    free(outData);
//    outData = NULL;
//    
//    return nil;
//}

@end
