/***************************************************************************
 *
 * Copyright (c) 2008 Baidu.com, Inc. All Rights Reserved
 * $Id: ucrypt.cpp,v 1.6 2008/03/03 08:02:36 wangjp2 Exp $
 *
 **************************************************************************/

/**
 * @file ucrypt.cpp
 * @author wangjp
 * @version $Revision: 1.6 $
 * @brief userid usernameº”√‹Ω‚√‹ µœ÷
 *
 **/

#include "ucrypt.h"

#pragma warning(disable: 4244)

namespace{
    const int radix = 16;
    const u_char IS_DIGIT_LETTER[256]=
    {   16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,
        16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,
        16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,
        0,1,2,3,4,5,6,7,8,9,16,16,16,16,16,16,
        16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,
        16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,
        16,10,11,12,13,14,15,16,16,16,16,16,16,16,16,16,
        16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,
        16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,
        16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,
        16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,
        16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,
        16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,
        16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,
        16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,
        16,16,16,16,16,16,16,16,16,16,16,16,16,16,16,16         };
    char digit_array[radix] = {'0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'};
    char* encode_char(u_char input, char* output)
    {
        output[0] = digit_array[input/radix];
        output[1] = digit_array[input%radix];
        return output+2;
    }
#define char2hex(c) IS_DIGIT_LETTER[((u_char) c)]!=16?IS_DIGIT_LETTER[((u_char) c)]:-1;
    const char* decode_char(const char* input, u_char& output)
    {
        int ret0 = char2hex(input[0]);
        int ret1 = char2hex(input[1]);
        if(ret0<0 || ret1<0) {
            return NULL;
        } else {
            output = (u_char)(ret0*radix + ret1);
            return input+2;
        }
    }
}

uintptr_t user_url_encode(u_int userid, const char* username, char* url, size_t len)
{
    if((NULL==username) || (NULL==url) || (0==len))
        return -1;
    size_t unamelen = 0;
    u_char* userid_str = reinterpret_cast<unsigned char*>(&userid);
    char* url_pos = url;
    if(len-1 < (strlen(username)+4)*2) {
        return -1;
    }
    url_pos = encode_char(userid_str[0], url_pos);
    url_pos = encode_char(userid_str[1], url_pos);
    
    unamelen = strlen(username);
    for(u_int i=0; i<unamelen; ++i) {
        url_pos = encode_char((u_char)username[i], url_pos);
    }
    url_pos = encode_char(userid_str[2], url_pos);
    url_pos = encode_char(userid_str[3], url_pos);
    *url_pos = '\0';
    return url_pos-url;
}

uintptr_t user_url_decode(const char* url, u_int& userid, char* username, size_t username_len)
{
    if((NULL==url) || (NULL==username) || (0==username_len))
        return -1;
    u_char* userid_str = reinterpret_cast<u_char*>(&userid);
    const char* url_pos = url;
    size_t url_len = strlen(url);
    
    if(url_len%2 || url_len/2<4 || url_len/2-4>username_len-1) {
        return -1;
    }
    
    url_pos = decode_char(url_pos, userid_str[0]);
    if(NULL == url_pos) {
        return -1;
    }
    url_pos = decode_char(url_pos, userid_str[1]);
    if(NULL == url_pos) {
        return -1;
    }
    
    memset(username, 0, username_len);
    for(u_int i=0; i<url_len/2-4; ++i) {
        url_pos = decode_char(url_pos, (u_char&)username[i]);
        if(NULL == url_pos) {
            return -1;
        }
    }
    
    url_pos = decode_char(url_pos, userid_str[2]);
    if(NULL == url_pos) {
        return -1;
    }
    url_pos = decode_char(url_pos, userid_str[3]);
    if(NULL == url_pos) {
        return -1;
    }
    return url_pos-url;
}

#ifdef UCRYPT_TEST

struct check_table_t {
	u_int userid;
	char username[50];
	char url[200];
};

static const check_table_t table[] ={
	{14409414, "joriasoka", "c6de6a6f726961736f6b61db00"},
	{2837521, "jlzhangyu", "114c6a6c7a68616e6779752b00"},
	{763529, "hkz1231", "89a6686b7a313233310b00"},
	{34567, "≥¬∫„∫∆", "0787b3c2bae3bac60000"},
	{28, "grant", "1c006772616e740000"}
};

int main()
{
	for(int i=0; i<100000; ++i) {
		unsigned int userid;
		char username[50];
		char url[200];
		//	printf("i = %d\n", i);
        
		if(user_url_encode(table[i%5].userid, table[i%5].username, url, sizeof(url)) < 0) {
			printf("picurl_encode fail\n");
			return -1;
		}
		if(strcmp(url, table[i%5].url)) {
			printf("url[%s] diff fail\n", url);
			return -1;
		}
        
		//	printf("url[%s]\n", url);
		if(user_url_decode(table[i%5].url, userid, username, sizeof(username)) < 0) {
			printf("decode fail\n");
			return -1;
		}
		if(strcmp(table[i%5].username, username)) {
			printf("username[%s] diff fail\n", username);
			return -1;
		}
		if(table[i%5].userid != userid) {
			printf("userid[%d] diff fail\n", userid);
			return -1;
		}
	}
}
#endif
