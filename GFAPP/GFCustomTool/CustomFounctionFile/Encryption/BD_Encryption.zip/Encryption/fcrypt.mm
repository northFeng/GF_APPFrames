/** $Id: fcrypt.cpp,v 1.7 2009/07/23 08:47:20 scmpf Exp $ */
#include "fcrypt.h"

#include <assert.h>
#include <stdio.h>

//typedef unsigned __int16 u_short;
//typedef unsigned __int8 u_char;

//这部分从glibc 中copy出来
//{
#define TYPE_0      0
#define BREAK_0     8
#define DEG_0       0
#define SEP_0       0

/* x**7 + x**3 + 1.  */
#define TYPE_1      1
#define BREAK_1     32
#define DEG_1       7
#define SEP_1       3

/* x**15 + x + 1.  */
#define TYPE_2      2
#define BREAK_2     64
#define DEG_2       15
#define SEP_2       1

/* x**31 + x**3 + 1.  */
#define TYPE_3      3
#define BREAK_3     128
#define DEG_3       31
#define SEP_3       3

/* x**63 + x + 1.  */
#define TYPE_4      4
#define BREAK_4     256
#define DEG_4       63
#define SEP_4       1


/* Array versions of the above information to make code run faster.
 *    Relies on fact that TYPE_i == i.  */

#define MAX_TYPES   5   /* Max number of types above.  */

/*
 static int32_t randtbl[DEG_3 + 1] =
 {
 TYPE_3,
 
 -1726662223, 379960547, 1735697613, 1040273694, 1313901226,
 1627687941, -179304937, -2073333483, 1780058412, -1989503057,
 -615974602, 344556628, 939512070, -1249116260, 1507946756,
 -812545463, 154635395, 1388815473, -1926676823, 525320961,
 -1009028674, 968117788, -123449607, 1284210865, 435012392,
 -2017506339, -911064859, -370259173, 1132637927, 1398500161,
 -205601318,
 };
 */
//}



#define FCRYPT_D2HSTR_MAX_DATA_LEN  1024
#define FAST_CRYPT_RAW_SECRET_MAXSIZE 600
/**必须保证这些原始秘密长度>512 */
static const char _g_fcrypt_rawsecret[FAST_CRYPT_RAW_SECRET_MAXSIZE] =
"\xA1\xB6\xC0\xC1\xA2\xBA\xAE\xC7\xEF\x0D\x0A\xCF\xE6\xBD\xAD\xB1\xB1"
"\x3D\xC8\xA5\x0D\x0A\xE9\xD9\xD7\xD3\xD6\xDE\xCD\xB7\x0D\x0A\xBF\xB4"
"\xB2\xCD\xF2\xC9\xBD\xBA\xEC\xB1\xE9\x0D\x0A\xB2\xE3\xC1\xD6\xBE\xA1"
"\xC8\xA5\x0D\x0A\xE9\xD9\xD7\xD3\xD6\xDE\xCD\xB7\x0D\x0A\xBF\xB4"
"\xCD\xF2\xC9\xBD\xBA\xEC\xB1\xE9\x0D\x0A\xB2\xE3\xC1\xD6\xBE\xA1"
"\xC8\xBE\x0D\x0A\xC2\xFE\xBD\xAD\xB1\xCC\xCD\xB8\x0D\x0A\xB0\xD9"
"\xF4\xB4\xD5\xF9\xC1\xF7\x0D\x0A\xD3\xA5\xBB\xF7\xB3\xA4\xBF\xD5"
"\x0D\x0A\xD3\xE3\xCF\xE8\xC7\xB3\xB5\xD7\x0D\x0A\xCD\xF2\xCE\xEF"
"\xCB\xAA\xCC\xEC\xBE\xBA\xD7\xD4\xD3\xC9\x0D\x0A\xE2\xEA\xC1\xC8"
"\xC0\xAA\x0D\x0A\xCE\xCA\xB2\xD4\xC3\xA3\xB4\xF3\xB5\xD8\x0D\x0A"
"\xCB\xAD\xD6\xF7\xB3\xC1\xB8\xA1\x0D\x0A\xD0\xAF\xC0\xB4\xB0\xD9"
"\xC2\xC2\xD4\xF8\xD3\xCE\x0D\x0A\xD2\xE4\xCD\xF9\xCE\xF4\xE1\xBF"
"\xE1\xC9\xCB\xEA\xD4\xC2\xB3\xED\x0D\x0A\xC7\xA1\xCD\xAC\xD1\xA7"
"\xC9\xD9\xC4\xEA\x0D\x0A\xB7\xE7\xBB\xAA\xD5\xFD\xC3\xAF\x0D\x0A"
"\xCA\xE9\xC9\xFA\xD2\xE2\xC6\xF8\x0D\x0A\xBB\xD3\xB3\xE2\xB7\xBD"
"\xE5\xD9\x0D\x0A\xD6\xB8\xB5\xE3\xBD\xAD\xC9\xBD\x0D\x0A\xBC\xA4"
"\xD1\xEF\xCE\xC4\xD7\xD6\x0D\x0A\xB7\xE0\xCD\xC1\xB5\xB1\xC4\xEA"
"\xCD\xF2\xBB\xA7\xBA\xEE\x0D\x0A\xD4\xF8\xBC\xC7\xB7\xF1\x0D\x0A"
"\xB5\xBD\xD6\xD0\xC1\xF7\xBB\xF7\xCB\xAE\x0D\x0A\xC0\xCB\xB6\xF4"
"\xB7\xC9\xD6\xDB\x0D\x0A\xBA\xE1\xBF\xD5\xB3\xF6\xCA\xC0\x0D\x0A"
"\xC3\xA7\xC0\xA5\xC2\xD8\x0D\x0A\xD4\xC4\xBE\xA1\xC8\xCB\xBC\xE4"
"\xB4\xBA\xC9\xAB\x0D\x0A\xB7\xC9\xC6\xF0\xD3\xF1\xC1\xFA\xC8\xFD"
"\xB0\xD9\xCD\xF2\x0D\x0A\xBD\xC1\xB5\xC3\xD6\xDC\xCC\xEC\xBA\xAE"
"\xB3\xB9\x0D\x0A\xCF\xC4\xC8\xD5\xCF\xFB\xC8\xDA\x0D\x0A\xBD\xAD"
"\xBA\xD3\xBA\xE1\xD2\xE7\x0D\x0A\xC8\xCB\xBB\xF2\xCE\xAA\xD3\xE3"
"\xB1\xEE\x0D\x0A\xC7\xA7\xC7\xEF\xB9\xA6\xD7\xEF\x0D\x0A\xCB\xAD"
"\xC8\xCB\xD4\xF8\xD3\xEB\xC6\xC0\xCB\xB5\x0D\x0A\xB6\xF8\xBD\xF1"
"\xCE\xD2\xCE\xBD\xC0\xA5\xC2\xD8\x0D\x0A\xB2\xBB\xD2\xAA\xD5\xE2"
"\xB8\xDF\x0D\x0A\xB2\xBB\xD2\xAA\xD5\xE2\xB6\xE0\xD1\xA9\x0D\x0A"
"\xB0\xB2\xB5\xC3\xD2\xD0\xCC\xEC\xB3\xE9\xB1\xA6\xBD\xA3\x0D\x0A"
"\xB0\xD1\xC8\xEA\xB2\xC3\xCE\xAA\xC8\xFD\xBD\xD8\x0D\x0A\xD2\xBB"
"\xBD\xD8\xD2\xC5\xC5\xB7\x0D\x0A\xD2\xBB\xBD\xD8\xD4\xF9\xC3\xC0"
"\x0D\x0A\xD2\xBB\xBD\xD8\xBB\xB9\xB6\xAB\xB9\xFA\x0D\x0A\xCC\xAB"
"\xC6\xBD\xCA\xC0\xBD\xE7\x0D\x0A\xBB\xB7\xC7\xF2\xCD\xAC\xB4\xCB"
"\xC1\xB9\xC8\xC8";

struct fcrypt_t {
	char rawsecret[FAST_CRYPT_RAW_SECRET_MAXSIZE];
};

static fcrypt_t _g_fcrypt;

u_short fcrypt_checksum_short (const void *ptr, unsigned len);
unsigned int fcrypt_checksum_int (const void *ptr, unsigned len);
/** 转换出小写的十六进制字符串 */
static int fcrypt_encode_hex_low(const void *data, int length, char *buffer,	int buflen)
{
	static const char shex[] = "0123456789abcdef";
	const unsigned char *p;
	int i;
    
	if (buflen <=length*2 )
		return -1;
	for (p = (unsigned char*)data, i = 0; i < length && (i * 2) < (buflen - 1); p++, i++) {
		buffer[i * 2]       = shex[(*p & 0xf0) >> 4];
		buffer[(i * 2) + 1] = shex[(*p & 0x0f)];
	}
	buffer[length * 2] = '\0';
	return length*2;
}

static int fcrypt_decode_hex(const char *data, void *buffer, int buflen)
{
	const char *p;
	int i;
	unsigned char part;
    
	int dlen = (int)strlen(data);
	if (buflen <dlen/2 )
		return -1;
	memset(buffer, 0, buflen);
    
	for (p = data, i = 0; i<dlen; p++, i++) {
		if (data[i] >= '0' && data[i] <= '9')
			part = data[i] - '0';
		else if (data[i] >= 'A' && data[i] <= 'F')
			part = data[i] - 'A' + 10;
		else if (data[i] >= 'a' && data[i] <= 'f')
			part = data[i] - 'a' + 10;
		else
			return -1;
		if (i % 2 == 0)
			part <<= 4;
		((char*)buffer)[i / 2] |= part;
	}
	if( buflen>dlen/2 )
		((char*)buffer)[dlen/2] = 0;
	return dlen/2;
}


/** 计算校验和, from tcp/ip */
u_short fcrypt_checksum_short (const void *ptr, unsigned len)
{
	long  sum       = 0;
	long  slen      = (long) len;   /* must be signed */
	const u_short *wrd = (const u_short*) ptr;
	while (slen > 1) {
		sum  += *wrd++;
		slen -= 2;
	}
	if (slen > 0)
		sum += (*(const u_char*)wrd)&0xff;
	/*@-shiftsigned@*/
	while (sum >> 16)
		sum = (sum & 0xFFFF) + (sum >> 16);
	return (u_short)sum;
}
unsigned int fcrypt_checksum_int (const void *ptr, unsigned len)
{
	unsigned int  sum       = 0;
	long  slen      = (long) len;   /* must be signed */
	const u_short *wrd = (const u_short*) ptr;
	while (slen > 1) {
		sum  += *wrd++;
		slen -= 2;
	}
	if (slen > 0)
		sum += (*(const u_char*)wrd)&0xff;
	return sum;
}

/** 随机数生成函数, from glibc 2.3.4 */
int fcrypt_random( struct random_data *buf, int32_t *result )
{
	int32_t *state;
    
	if (buf == NULL || result == NULL) {
		goto fail;
	}
    
	state = buf->state;
    
	if (buf->rand_type == TYPE_0) {
		int32_t val = state[0];
		val = ((state[0] * 1103515245) + 12345) & 0x7fffffff;
		state[0] = val;
		*result = val;
	}
	else {
		int32_t *fptr = buf->fptr;
		int32_t *rptr = buf->rptr;
		int32_t *end_ptr = buf->end_ptr;
		int32_t val;
		
		//glibc 2.3.4原始编码风格
		val = *fptr += *rptr;
		/* Chucking least random bit.  */
		*result = (val >> 1) & 0x7fffffff;
		++fptr;
		if (fptr >= end_ptr) {
			fptr = state;
			++rptr;
		}
		else {
			++rptr;
			if (rptr >= end_ptr) {
				rptr = state;
			}
		}
		buf->fptr = fptr;
		buf->rptr = rptr;
	}
    
	return 0;
    
fail:
    return -1;
}

/** 随机数生成的初始化函数, from glibc 2.3.4 */
int fcrypt_srandom( unsigned int seed, struct random_data *buf )
{
	int type;
	int32_t *state;
	long int i;	/**<  long使用： glibc 2.3.4原始编码风格   */
	long int word;
	int32_t *dst;
	int kc;
    
	if (buf == NULL) {
		goto fail;
	}
    
	type = buf->rand_type;
	if ((unsigned int) type >= MAX_TYPES) {
		goto fail;
	}
    
	state = buf->state;
	/* We must make sure the seed is not 0.  Take arbitrarily 1 in this case.  */
	if (seed == 0) {
		seed = 1;
	}
	state[0] = (int32_t)seed;
	if (type == TYPE_0) {
		goto done;
	}
    
	dst = state;
	word = seed;
	kc = buf->rand_deg;
	for (i = 1; i < kc; ++i) {
		/* This does:
         state[i] = (16807 * state[i - 1]) % 2147483647;
         but avoids overflowing 31 bits.  */
		long int hi = word / 127773;
		long int lo = word % 127773;
		word = 16807 * lo - 2836 * hi;
		if (word < 0) {
			word += 2147483647;
		}
		*++dst = word;
	}
    
	buf->fptr = &state[buf->rand_sep];
	buf->rptr = &state[0];
	kc *= 10;
	while (--kc >= 0) {
		int32_t discard;
		(void) fcrypt_random(buf, &discard);
	}
	
done:
    return 0;
fail:
    return -1;
}
/**用不同的字符串做密钥*/
void __fcrypt_init( int *praw_dest, const char* crypt_key )
{
	assert(praw_dest && crypt_key && strlen(crypt_key)>0);
    
	unsigned int seed = fcrypt_checksum_int( crypt_key, (unsigned)strlen(crypt_key) );
	//使用线程安全的随机函数
	int32_t randtbl[DEG_3 + 1] =
	{
		TYPE_3,
        
		-1726662223, 379960547, 1735697613, 1040273694, 1313901226,
        1627687941, -179304937, -2073333483, 1780058412, -1989503057,
        -615974602, 344556628, 939512070, -1249116260, 1507946756,
        -812545463, 154635395, 1388815473, -1926676823, 525320961,
        -1009028674, 968117788, -123449607, 1284210865, 435012392,
        -2017506339, -911064859, -370259173, 1132637927, 1398500161,
        -205601318,
    };
    random_data statbuf =
 	{
		&randtbl[SEP_3 + 1],
		&randtbl[1],
		&randtbl[1],
		TYPE_3,
		DEG_3,
		SEP_3,
		&randtbl[sizeof (randtbl) / sizeof (randtbl[0])]
    };
	//srandom(seed);
    //srandom_r(seed, &statbuf);
	fcrypt_srandom(seed, &statbuf);
	int r=0;
	const int *praw_src = (const int*)_g_fcrypt_rawsecret;
	for (int i=0; i<(int)(sizeof(_g_fcrypt_rawsecret)/sizeof(int)); i++) {
		//r = random();
        //random_r(&statbuf, &r);
		fcrypt_random(&statbuf, &r);
		praw_dest[i] = praw_src[i] + r;
	}
}

int fcrypt_init( const char* crypt_key )
{
	if( NULL==crypt_key||strlen(crypt_key)<=0 )
		return -1;
    
	__fcrypt_init((int*)_g_fcrypt.rawsecret, crypt_key);
	return 0;
}



fcrypt_t* fcrypt_create( const char* crypt_key )
{
	if( NULL==crypt_key||strlen(crypt_key)<=0 )
		return NULL;
    
	fcrypt_t* new_fcrypt = (fcrypt_t*) malloc(sizeof(fcrypt_t));
	if(new_fcrypt == NULL) {
		return NULL;
	}
    
	__fcrypt_init((int*)new_fcrypt->rawsecret, crypt_key);
	return new_fcrypt;
}

int fcrypt_destroy( fcrypt_t* pfc )
{
	if( NULL==pfc ) {
		return -1;
	}
	free(pfc);
	return 0;
}

int fcrypt_encode( const void* pdata, int datalen, void *pbuf, int buflen )
{
	return fcrypt_encode(&_g_fcrypt, pdata, datalen, pbuf, buflen);
}

/**将数据加密*/
int fcrypt_encode( fcrypt_t* pfc, const void* pdata, int datalen, void *pbuf, int buflen )
{
	if( pfc==NULL || buflen<datalen )
		return -1;
	long  slen      = (long) datalen;   /* must be signed */
    const u_short *rdata = (const u_short*) pdata;
	u_short *wdata = (u_short*) pbuf;
	const u_short *key = (const u_short*) pfc->rawsecret;
	u_short magic = slen;
	if( slen>=2 ) {
		rdata = (const u_short*)((u_char*)pdata+datalen-2);
		wdata = (u_short*)((u_char*)pbuf+datalen-2);
		magic = slen + *rdata;
		*wdata = (*rdata)^(key[slen&0xff]);
		slen-=2;
        
		rdata = (u_short*)pdata;
		wdata = (u_short*)pbuf;
	}
	while (slen > 1) {
		*wdata++ = (*rdata++)^(key[(magic++)&0xff]);
		slen -= 2;
	}
	if (slen > 0){
		*((u_char*)wdata) = ((*((u_char*)rdata))^((key[(magic++)&0xff])&0xff))&0xff;
	}
	return datalen;
}

int fcrypt_decode( const void* pdata, int datalen, void *pbuf, int buflen )
{
	return fcrypt_decode(&_g_fcrypt, pdata, datalen, pbuf, buflen);
}

int fcrypt_decode( fcrypt_t* pfc, const void* pdata, int datalen, void *pbuf, int buflen )
{
	if( pfc==NULL || buflen<datalen )
		return -1;
    long  slen      = (long) datalen;   /* must be signed */
	const u_short *rdata = (const u_short*) pdata;
	u_short *wdata = (u_short*) pbuf;
	const u_short *key = (const u_short*) pfc->rawsecret;
	u_short magic = slen;
	if( slen>=2 ) {
		rdata = (const u_short*)((u_char*)pdata+datalen-2);
		wdata = (u_short*)((u_char*)pbuf+datalen-2);
		*wdata = (*rdata)^(key[slen&0xff]);
		magic = slen + *wdata;
		slen-=2;
        
		rdata = (u_short*)pdata;
		wdata = (u_short*)pbuf;
	}
	while (slen > 1) {
		*wdata++ = (*rdata++)^(key[(magic++)&0xff]);
		slen -= 2;
	}
	if (slen > 0){
		*((u_char*)wdata) = ((*((u_char*)rdata))^((key[(magic++)&0xff])&0xff))&0xff;
	}
	return datalen;
}

/**
 * 将数据+校验->加密, 多4个字节
 * -1, 参数错误
 **/
int fcrypt_encode_hmac( const void* pdata, int datalen, void *pbuf, int buflen )
{
	return fcrypt_encode_hmac(&_g_fcrypt, pdata, datalen, pbuf, buflen);
}

int fcrypt_encode_hmac( fcrypt_t* pfc, const void* pdata, int datalen, void *pbuf, int buflen )
{
	if( pfc==NULL || datalen+4>buflen )
		return -1;
	memcpy( pbuf, pdata, datalen );
	unsigned int sum = fcrypt_checksum_int( pdata, datalen );
	sum = (sum>>16)|((sum<<16)&0xffff0000);
	*(unsigned int*)((u_char*)pbuf+datalen) = sum;
	return fcrypt_encode( pfc, pbuf, datalen+4, pbuf, buflen );
}
/**
 * 将数据解密 -->校验, 多4个字节
 * -1, 参数错误
 * -2, 校验错误
 **/
int fcrypt_decode_hmac( const void* pdata, int datalen, void *pbuf, int buflen )
{
	return fcrypt_decode_hmac(&_g_fcrypt, pdata, datalen, pbuf, buflen);
}

int fcrypt_decode_hmac( fcrypt_t* pfc, const void* pdata, int datalen, void *pbuf, int buflen )
{
	if( pfc==NULL || datalen<4 || datalen>buflen )
		return -1;
	if( fcrypt_decode( pfc, pdata, datalen, pbuf, buflen )<0 )
		return -1;
	unsigned int oldsum=*(unsigned int*)((u_char*)pbuf+datalen-4);
	unsigned int sum = fcrypt_checksum_int( pbuf, datalen-4 );
	sum = (sum>>16)|((sum<<16)&0xffff0000);
	if( oldsum!=sum )
		return -2;
	return datalen-4;
}

/** 将id加密+校验和, 并以十六进制字符串组织
 * 返回值: 字符串长长度
 *       <0, 由于buf长度不够
 ***/
int fcrypt_id_2hstr( unsigned int id1, unsigned int id2, char* pstrbuf, int buflen )
{
	return fcrypt_id_2hstr(&_g_fcrypt, id1, id2, pstrbuf, buflen);
}

int fcrypt_id_2hstr( fcrypt_t* pfc, unsigned int id1, unsigned int id2, char* pstrbuf, int buflen )
{
	if( pfc==NULL || pstrbuf==NULL )
		return -1;
	*(char*)pstrbuf = 0;
	unsigned int id[2];
	id[0] = id1, id[1] = id2;
	return fcrypt_data_2hstr( pfc, id, (int)sizeof(id), pstrbuf, buflen );
}

/** 将id解密+校验数据, 并以十六进制字符串组织
 * 返回值: >=0成功
 *       <0, 校验错误
 **/
int fcrypt_hstr_2id( const char* phexstr, unsigned int *pid1, unsigned int *pid2 )
{
	return fcrypt_hstr_2id(&_g_fcrypt, phexstr, pid1, pid2);
}

int fcrypt_hstr_2id( fcrypt_t* pfc, const char* phexstr, unsigned int *pid1, unsigned int *pid2 )
{
	if(pfc==NULL || phexstr==NULL || pid1==NULL || pid2==NULL)
		return -1;
	*pid1 = *pid2 = 0;
	int buf[3];
	int ret = fcrypt_hstr_2data( pfc, phexstr, buf, (int)sizeof(buf) );
	if( ret!=(int)sizeof(int)*2 )
		return -1;
	*pid1 = buf[0];
	*pid2 = buf[1];
	return ret;
}

int fcrypt_data_2hstr( void* pdata, int datalen, void* pstrbuf, int buflen )
{
	return fcrypt_data_2hstr(&_g_fcrypt, pdata, datalen, pstrbuf, buflen);
}

int fcrypt_data_2hstr( fcrypt_t* pfc, void* pdata, int datalen, void* pstrbuf, int buflen )
{
	if(pfc==NULL || pdata==NULL || pstrbuf==NULL)
		return -1;
	char enbuf[FCRYPT_D2HSTR_MAX_DATA_LEN+16];
	if( datalen>FCRYPT_D2HSTR_MAX_DATA_LEN || buflen<(datalen+4)*2 )
		return -3;
	int ret=fcrypt_encode_hmac( pfc, pdata, datalen, enbuf, (int)sizeof(enbuf) );
	if( ret <0 )
		return -2;
	return fcrypt_encode_hex_low(enbuf, datalen+4, (char*)pstrbuf, buflen);
}

int fcrypt_hstr_2data( const char* phexstr, void* pdatabuf, int buflen )
{
	return fcrypt_hstr_2data(&_g_fcrypt, phexstr, pdatabuf, buflen);
}

int fcrypt_hstr_2data( fcrypt_t* pfc, const char* phexstr, void* pdatabuf, int buflen )
{
	if(pfc==NULL || phexstr==NULL || pdatabuf==NULL)
		return -1;
	char debuf[FCRYPT_D2HSTR_MAX_DATA_LEN+16];
	size_t slen = strlen(phexstr);
	if( slen>(FCRYPT_D2HSTR_MAX_DATA_LEN+4)*2 )
		return -3;
	int ret= fcrypt_decode_hex( (char*)phexstr, debuf, (int)sizeof(debuf));
	if( ret!=slen/2 )
		return -2;
	return fcrypt_decode_hmac( pfc, debuf, ret, pdatabuf, buflen );
}

#ifdef FCRYPT_TEST
static int test_crypt(fcrypt_t* pfc, int count )
{
	char data[1024];
	char en_buf[1024], de_buf[1024];
	// init
	for( int i=0; i<1024; i++ )
		data[i] = random()&0xff;
    
	int ret=0;
	if( count>1024 ) count=1024;
	for( int i=0; i<count; i++ )
	{
		if( (ret=fcrypt_encode( pfc, data, i, en_buf, (int)sizeof(en_buf) ))!=i )
			printf("%d ret:%d encode failed.\n", i, ret );
		else if( (ret=fcrypt_decode( pfc, en_buf, i, de_buf, (int)sizeof(de_buf)))!=i )
			printf("%d ret:%d decode failed. \n", i, ret );
		else if( memcmp( data, de_buf, i )!=0 )
			printf("%d encode/decode, failed! \n", i);
		else printf("%d encode/decode, success\n", i );
	}
	return 0;
}

static int test_crypt_hmac(fcrypt_t* pfc, int count )
{
	char data[1024];
	char en_buf[1024+4], de_buf[1024+4];
	// init
	for( int i=0; i<1024; i++ )
		data[i] = random()&0xff;
    
	if( count>1024 ) count=1024;
	int ret=0;
	for( int i=0; i<count; i++ )
	{
		if( (ret=fcrypt_encode_hmac( pfc, data, i, en_buf, (int)sizeof(en_buf) ))!=i+4 )
			printf("%d ret:%d encode-hmac failed.\n", i, ret );
		else {
			if( (ret=fcrypt_decode_hmac( pfc, en_buf, ret, de_buf, (int)sizeof(de_buf) ))!=i )
				printf("%d ret:%d decode-hmac failed.\n", i, ret );
			else if( memcmp( data, de_buf, i )!=0 )
				printf("%d encode/decode hmac, failed! \n", i);
			else printf("%d encode/decode hmac, success\n", i);
		}
	}
	return 0;
}
static int test_crypt_hstr(fcrypt_t* pfc, int count )
{
	char data[1024];
	char en_buf[1024+16], de_buf[1024+16];
	// init
	for( int i=0; i<1024; i++ )
		data[i] = random()&0xff;
    
	if( count>1024 ) count=1024;
	int ret=0;
	for( int i=0; i<count; i++ )
	{
		if( (ret=fcrypt_data_2hstr( pfc, data, i, en_buf, (int)sizeof(en_buf) ))!=(i+4)*2 )
			printf("%d ret:%d encode-hstr failed.\n", i, ret );
		else {
            //			printf("%d ret:%d en_buf:%s\n", i, ret, en_buf);
			if( (ret=fcrypt_hstr_2data( pfc, en_buf, de_buf, (int)sizeof(de_buf) ))!=i )
				printf("%d ret:%d decode-hstr failed.\n", i, ret );
			else if( memcmp( data, de_buf, i )!=0 )
				printf("%d encode/decode hstr, failed! \n", i);
			else printf("%d encode/decode hstr, success\n", i);
		}
	}
	return 0;
}

static int test_id(fcrypt_t* pfc, int count )
{
	int data[1024];
	char hex_buf[1024+4];
	// init
	for( int i=0; i<1024; i++ )
		data[i] = random()&0xff;
    
	if( count>1024 ) count=1024;
	int ret=0;
	unsigned int id1,id2;
	int d1,d2;
	for( int i=0; i<count; i++ )
	{
		d1 = data[i];
		d2 = data[(i+1)%1024];
		ret = fcrypt_id_2hstr( pfc, d1, d2, hex_buf, (int)sizeof(hex_buf) );
		if( ret!= 24 )
			printf("%d ret:%d encode-hmac failed.\n", i, ret );
		else {
			ret = fcrypt_hstr_2id( pfc, hex_buf, &id1, &id2);
            //			printf("%d %s d1:%d d2:%d id1:%d id2:%d\n", i, hex_buf, d1, d2, id1, id2 );
			if( ret<0 )
				printf("%d ret:%d failed.\n", i, ret );
			else if( d1==(int)id1 && d2==(int)id2 )
				printf("%d id-encode/decode success\n", i );
			else printf("%d id-encode/decode, failed.", i );
		}
	}
	return 0;
}

int main()
{
	int loop=512;
	int i=50;
	fcrypt_init( "zhaoxw" );
    
	fcrypt_t* fcrypt_asdf = fcrypt_create( "asdfasdf" );
	fcrypt_t* fcrypt_ffff = fcrypt_create( "fffffffffffff" );
	fcrypt_t* fcrypt_1213 = fcrypt_create( "12132asdfas" );
    
    
	for( i=0; i<loop; i++ )
	{
		fcrypt_t* fcrypt_zhaoxw123 = fcrypt_create( "zhaoxw123" );
		test_crypt( fcrypt_zhaoxw123, i );
		fcrypt_destroy(fcrypt_zhaoxw123);
	}
	char str1[256], str2[256], str3[256];
	int id1 = 1, id2 = 3;
    
	//should use "zhaoxw"
	fcrypt_id_2hstr( id1, id2++, str1, sizeof(str1) );
	fcrypt_id_2hstr( id1, id2++, str2, sizeof(str2) );
	fcrypt_id_2hstr( id1, id2++, str3, sizeof(str3) );
	if( strncmp( str1, "a7d56fe52bf824d08fa496cf", 24)!=0 ||
       strncmp( str2, "6ee528f820d08fa40c3b97cf", 24)!=0 ||
       strncmp( str3, "29f824d08aa40c3b556b94cf", 24)!=0 )
        printf("%d encode/decode hstr, failed! \n", i);
    
	for( i=0; i<loop; i++ )
	{
		test_crypt_hmac( fcrypt_asdf, i );
	}
	for( i=0; i<loop; i++ )
	{
		test_id( fcrypt_ffff, i );
	}
	for( i=0; i<loop; i++ )
	{
		test_crypt_hstr( fcrypt_1213, i );
	}
    
	fcrypt_destroy(fcrypt_asdf);
	fcrypt_destroy(fcrypt_ffff);
	fcrypt_destroy(fcrypt_1213);
	return 0;
}

#endif
