/***************************************************************************
 *
 * Copyright (c) 2008 Baidu.com, Inc. All Rights Reserved
 * $Id: ucrypt.h,v 1.3 2008/03/03 08:02:36 wangjp2 Exp $
 *
 **************************************************************************/


/**
 * @file ucrypt.h
 * @author wangjp(wangjiping@baidu.com)
 * @version $Revision: 1.3 $
 * @brief 用于userid和username加密解密的库
 *
 **/
#ifndef _UCRYPT_HEAD_FILE_
#define _UCRYPT_HEAD_FILE_
//#include "ul_def.h"

#include <stdlib.h>
#include <string.h>

//#define u_char      unsigned char
//#define u_short     unsigned short
//#define u_int       unsigned int
//#define u_int16     unsigned short
//#define u_int32     unsigned int

/**
 * @brief 加密userid和username, url填充加密字符串; 返回值>0表示成功, 否则失败
 *
 * @param [in]  userid          : userid
 * @param [in]  username        : username
 * @param [out] url             : 填充加密字符串
 * @param [in]  url_len         : buf长度
 * @return  >0成功 返回url长度 其他为失败
 * @author wangjp
 **/
uintptr_t user_url_encode(unsigned int userid, const char* username, char* url, size_t url_len);

/**
 * @brief 解密加密字符串url
 *
 * @param [in]  url             : url
 * @param [out] userid          : 传入引用,返回userid
 * @param [out] username        : 返回username
 * @param [in]  username_len    : buf长度
 * @return  >0成功,否则失败
 * @author wangjp
 **/
uintptr_t user_url_decode(const char* url, unsigned int &userid, char* username, size_t username_len);


#endif
