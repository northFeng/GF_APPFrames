//
//  NSDateFormatter+BD.m
//  baiduhi
//
//  Created by Li,Zhange on 2019/12/26.
//  Copyright © 2019 Baidu. All rights reserved.
//

#import "NSDateFormatter+BD.h"

@implementation NSDateFormatter (BD)
+ (instancetype)sharedFormatter{
    static dispatch_once_t onceToken;
    static NSDateFormatter * f;
    dispatch_once(&onceToken, ^{
        f = [[NSDateFormatter alloc] init];
    });    
    return f;
}

@end
