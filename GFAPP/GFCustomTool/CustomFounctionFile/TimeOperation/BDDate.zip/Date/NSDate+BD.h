//
//  NSDate+BD.h
//  baiduhi
//
//  Created by baidu on 15/12/14.
//  Copyright © 2015年 Baidu. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSTimeInterval calibrationParam;//与服务器的校准时间偏差参数 单位：秒

@interface NSDate (BD)

+ (NSDateFormatter *)sharedBDyyMMddFormatter;
+ (NSDateFormatter *)sharedBDHHmmFormatter;
+ (NSDateFormatter *)sharedBDMonthDayFormatter;
+ (NSDateFormatter *)sharedBDyyyyMMddFormatter;

+ (uint64_t)getClientAbsoluteTime;

+ (NSDate *)calibrationNow;

+ (NSTimeInterval)timeIntervalForCalibrationNow;

// 计算度龄
+ (NSString *)calculateDuageWithJoinDate:(NSString *)joinDateStr;

//是否为同一天 
+ (BOOL)isSameDay:(NSDate*)date1 date2:(NSDate*)date2;
/**
 @author Wang Bo , 2016-12-26 16:32:43
 
 将毫秒时间转换为合适的描述语言，红包业务专用， F.E 1天内

 @param millisecond 毫秒单位的时间
 @return 合适的描述性语言
 */
+ (NSString *)changeMillisecondToBest:(NSUInteger) millisecond;


/// NULL(今天)/昨天/X月X日/X年X月X日 + 11:30
- (NSString *)stringForDaysAgoAgainstMidnightWithCalibrationDate;

/// 11:30(今天)/昨天/X月X日/X年X月X日
- (NSString *)timeFormaterForDaysAgoAgainstMidnightWithCalibrationDate;

/// 今天/昨天/X月X日/X年X月X日
- (NSString *)dateFormaterForDaysAgoAgainstMidnightWithCalibrationDate;


/// 相隔几天
/// @param fromDate
- (NSInteger)dayPassedFromDate:(NSDate *)fromDate;


+ (NSDate *)calibrationNowMilliSecond;
+ (NSTimeInterval)timeIntervalForCalibrationNowMilliSecond;

//是否为闰年
+ (BOOL)isLeapYear:(NSInteger)year;

/// 2019/02/01
- (NSString *)dateFormateForStandardDate;


/// 按照如下规则将时间转换成时长话术
/// 1. < 1 小时，显示为：* 分钟
/// 2. 1～72小时，显示为：* 小时
/// 3. > 72小时，显示为：* 天
/// 使用方需要分别实现如下国际化：
/// 分钟：xf_minutes
/// 小时：xf_hours
/// 天：xf_days
/// @param timeInterval 要转换的时间
+ (NSString *)durationStringFromTimeInterval:(NSTimeInterval)timeInterval;


/*
 计算两个时间点之间的天数
 参数：start，end单位：秒
 */
+ (NSUInteger)durationdaysWithStart:(long long)start end:(long long)end;
/*
计算两个时间点之间的月数,天数，年数
 */
+ (NSDateComponents *)durationDateComponentsWithStart:(long long)start end:(long long)end;

+ (NSDate *)longlongTimeAddMonthConversionToDate:(long long)startTime monthNumber:(int)monthNumber;

@end
