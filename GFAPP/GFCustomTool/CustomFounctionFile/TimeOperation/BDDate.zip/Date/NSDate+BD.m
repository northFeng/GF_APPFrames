//
//  NSDate+BD.m
//  baiduhi
//
//  Created by baidu on 15/12/14.
//  Copyright © 2015年 Baidu. All rights reserved.
//

#import "HiStringDefine.h"
#import "NSDate+BD.h"
#import "NSDate+Helper.h"
#import <mach/mach_time.h>
#include <sys/sysctl.h>

NSTimeInterval calibrationParam = 0; //与服务器的校准时间偏差参数 单位：秒

static NSString *leapYearString = @"31-29-31-30-31-30-31-31-30-31-30-31";
static NSString *nonLeapYearString = @"31-28-31-30-31-30-31-31-30-31-30-31";

static NSDateFormatter *BDyyMMddFormatter = nil;
static NSDateFormatter *BDHHmmFormatter = nil;
static NSDateFormatter *BDMonthDayFormatter = nil;
static NSDateFormatter *BDyyyyMMddFormatter = nil;

@implementation NSDate (BD)

+ (void)load {
    /*
     On iOS 7 and later NSDateFormatter is thread safe.
     */
    BDyyMMddFormatter = [[NSDateFormatter alloc] init];
    BDyyMMddFormatter.dateFormat = @"yy-MM-dd";
    BDHHmmFormatter = [[NSDateFormatter alloc] init];
    BDHHmmFormatter.dateFormat = @"HH:mm";
    BDyyyyMMddFormatter = [[NSDateFormatter alloc] init];
    BDyyyyMMddFormatter.dateFormat = @"yyyy-MM-dd";
    BDMonthDayFormatter = [[NSDateFormatter alloc] init];
    BDMonthDayFormatter.dateFormat = @"MM-dd";
}

+ (NSDateFormatter *)sharedBDyyMMddFormatter{
    return BDyyMMddFormatter;
}
+ (NSDateFormatter *)sharedBDHHmmFormatter{
    return BDHHmmFormatter;
}
+ (NSDateFormatter *)sharedBDMonthDayFormatter{
    return BDMonthDayFormatter;
}
+ (NSDateFormatter *)sharedBDyyyyMMddFormatter{
    return BDyyyyMMddFormatter;
}


/*
 参考链接:https://www.jianshu.com/p/0c1302c2679b
 sysctl会受系统时间影响，但他们二者做一个减法所得的值，就和系统时间无关了。这样就可以避免用户修改时间了。
 */
+ (uint64_t)getClientAbsoluteTime {
    //get system uptime since last boot
    struct timeval boottime;
    int mib[2] = {CTL_KERN, KERN_BOOTTIME};
    size_t size = sizeof(boottime);
    
    struct timeval now;
    struct timezone tz;
    gettimeofday(&now, &tz);
    
    double uptime = -1;
    
    if (sysctl(mib, 2, &boottime, &size, NULL, 0) != -1 && boottime.tv_sec != 0) {
        uptime = now.tv_sec - boottime.tv_sec;
        uptime += (double)(now.tv_usec - boottime.tv_usec) / 1000000.0;
    }
    
    return uptime;
}

+ (NSDate *)calibrationNow {
    return [NSDate dateWithTimeIntervalSince1970:[NSDate timeIntervalForCalibrationNow]];
}

+ (NSTimeInterval)timeIntervalForCalibrationNow {
    NSTimeInterval nowInterval = calibrationParam > 0 ? calibrationParam + [NSDate getClientAbsoluteTime] : [[NSDate date] timeIntervalSince1970];
    return nowInterval;
}

+ (uint64_t)getClientAbsoluteTimeMilliSecond {
    //get system uptime since last boot
    struct timeval boottime;
    int mib[2] = {CTL_KERN, KERN_BOOTTIME};
    size_t size = sizeof(boottime);
    
    struct timeval now;
    struct timezone tz;
    gettimeofday(&now, &tz);
    
    double uptime = -1;
    
    if (sysctl(mib, 2, &boottime, &size, NULL, 0) != -1 && boottime.tv_sec != 0) {
        uptime = (now.tv_sec - boottime.tv_sec) * 1000;
        uptime += (double)(now.tv_usec - boottime.tv_usec) / 1000.0;
    }
    
    return uptime;
}

+ (NSDate *)calibrationNowMilliSecond {
    return [NSDate dateWithTimeIntervalSince1970:[NSDate timeIntervalForCalibrationNowMilliSecond] / 1000.0];
}

+ (NSTimeInterval)timeIntervalForCalibrationNowMilliSecond {
    NSTimeInterval nowInterval = calibrationParam > 0 ? calibrationParam * 1000 + [NSDate getClientAbsoluteTimeMilliSecond] : (uint64_t)([[NSDate date] timeIntervalSince1970] * 1000);
    return nowInterval;
}

+ (NSString *)changeMillisecondToBest:(NSUInteger)millisecond {
    NSUInteger second = millisecond / 1000;
    NSUInteger minute = second / 60;
    NSUInteger hour = minute / 60;
    NSUInteger day = hour / 24;

    NSString *hourStr = hour > 0
                            ? (hour == 1)
                                  ? BDUIString(HISTR_Universal_Definition_NSDate_Time_One_Hour)
                                  : [NSString stringWithFormat:BDUIString(HISTR_Universal_Definition_NSDate_Time_Hours), hour % 24]
                            : @""; //@"%lu小时"

    NSString *minuteStr = minute > 0
                              ? ((minute == 1)
                                     ? BDUIString(HISTR_Universal_Definition_NSDate_Time_One_Minute)
                                     : [NSString stringWithFormat:BDUIString(HISTR_Universal_Definition_NSDate_Time_Minutes), minute % 60])
                              : @""; //@"%lu分"

    NSString *secondStr = second > 0
                              ? (second == 1)
                                    ? BDUIString(HISTR_Universal_Definition_NSDate_Time_One_Second)
                                    : [NSString stringWithFormat:BDUIString(HISTR_Universal_Definition_NSDate_Time_Seconds), second % 60]
                              : @""; // @"%lu秒"

    if (day >= 1) {
        //超过一天按24小时算
        return BDUIString(HISTR_Universal_Definition_NSDate_Time_24_Hour); //@"24小时"
    }
    if (hour >= 1) {
        //1~24小时内：X小时Y分钟
        return [NSString stringWithFormat:@"%@%@", hourStr, minuteStr];
    }
    if (minute >= 3) {
        //3~60分钟：X分
        return minuteStr;
    } else if (minute >= 1) {
        //1~3分钟：X分Y秒
        return [NSString stringWithFormat:@"%@%@", minuteStr, secondStr];
    }
    if (second > 0) {
        return secondStr;
    } else {
        //不足1秒按1秒算
        return BDUIString(HISTR_Universal_Definition_NSDate_Time_One_Second);
    }
}

// 入职日期到现在的度龄
+ (NSString *)calculateDuageWithJoinDate:(NSString *)joinDateStr {
    
    if (joinDateStr == nil || joinDateStr.length != 8) {
        HILogError(HILogContextNormal, @"calculateDuage parameter error: %@", joinDateStr);
        return @"--";
    }
    
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    [dateFormatter setDateFormat:@"yyyyMMdd"];
    NSDate *joinDate = [dateFormatter dateFromString:joinDateStr];
    NSString *currentDateStr = [NSDate stringFromDate:[NSDate calibrationNow] withFormat:@"yyyyMMdd"];
    NSDate *currentDate = [dateFormatter dateFromString:currentDateStr];
    currentDate = [currentDate dateByAddingTimeInterval:24*60*60];
    
    if(joinDate&&currentDate) {
        NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
        NSDateComponents *components = [calendar components:NSCalendarUnitMonth fromDate:joinDate toDate:currentDate options:0];
        NSInteger months = components.month;
        if(months<1) {
            return BDUIString(HISTR_USER_DUAGE_LESS_ONE_MONTH);
        } else if(months<12) {
            return [NSString stringWithFormat:BDUIString(HISTR_USER_DUAGE___MONTH),@(months)];
        } else {
            if(months%12 == 0) {
                return [NSString stringWithFormat:BDUIString(HISTR_USER_DUAGE___YEAR),@(months/12)];
            } else {
                return [NSString stringWithFormat:BDUIString(HISTR_USER_DUAGE___YEAR___MONTH),@(months/12),@(months%12)];
            }
        }
    } else {
        return @"--";
    }
}


/**
 *  是否为同一天
 */
+ (BOOL)isSameDay:(NSDate*)date1 date2:(NSDate*)date2
{
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    unsigned unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth |  NSCalendarUnitDay;
    NSDateComponents *comp1 = [calendar components:unitFlags fromDate:date1];
    NSDateComponents *comp2 = [calendar components:unitFlags fromDate:date2];
    
    return [comp1 day] == [comp2 day] &&
    [comp1 month] == [comp2 month] &&
    [comp1 year] == [comp2 year];
}

- (NSString *)stringForDaysAgoAgainstMidnightWithCalibrationDate {
    NSString *dateString = @"";

    NSDate *now = [NSDate calibrationNow];
    NSInteger daysPassedFromInterval = (int) [self timeIntervalSinceDate:now] / (60 * 60 * 24) * -1;

    // 日期
    if (daysPassedFromInterval > 2 || daysPassedFromInterval < 0) {
        dateString = [BDyyMMddFormatter stringFromDate:self];
    } else {
        NSInteger dayPassedFromDate = [now dayPassedFromDate:self];
        if (dayPassedFromDate == 0) {
            //今天
        } else if (dayPassedFromDate == 1) {
            //昨天
            dateString = BDUIString(HISTR_DATE_YESTERDAY);
        } else if (dayPassedFromDate == 2) {
            //前天
            dateString = BDUIString(HISTR_ID_Beforeday);
        } else {
            dateString = [BDyyMMddFormatter stringFromDate:self];
        }
    }

    //最后加上时间
    NSString *timeString = [BDHHmmFormatter stringFromDate:self];
    if (BDStringIsNil(dateString)) {
        return timeString;
    } else {
        return [[NSString stringWithFormat:@"%@ %@", dateString, timeString]
                stringByReplacingOccurrencesOfString:@"-" withString:@"/"];
    }
}

//今天 \ X年X月X日\ X月X日
- (NSString *)dateFormaterForDaysAgoAgainstMidnightWithCalibrationDate {
    NSString *dateString = @"";
    NSDate *now = [NSDate calibrationNow];
    
    NSInteger dayPassedFromDate = [now dayPassedFromDate:self];
    if (dayPassedFromDate == 0) {
        //今天
        dateString = BDUIString(HISTR_DATE_TODAY);
    } else if (dayPassedFromDate == 1) {
        //昨天
        dateString = BDUIString(HISTR_DATE_YESTERDAY);
    } else if ([self _isThisYear]) {
        //X月X日
        dateString = [BDMonthDayFormatter stringFromDate:self];
    } else {
        //X年X月X日
        dateString = [BDyyMMddFormatter stringFromDate:self];
    }
    return [dateString stringByReplacingOccurrencesOfString:@"-" withString:@"/"];
}

//今天 \ X年X月X日\ X月X日
- (NSString *)timeFormaterForDaysAgoAgainstMidnightWithCalibrationDate {
    NSString *dateString = @"";
    NSDate *now = [NSDate calibrationNow];
    
    NSInteger dayPassedFromDate = [now dayPassedFromDate:self];
    if (dayPassedFromDate == 0) {
        //今天
        dateString = [BDHHmmFormatter stringFromDate:self];
    } else if (dayPassedFromDate == 1) {
        //昨天
        dateString = BDUIString(HISTR_DATE_YESTERDAY);
    } else if ([self _isThisYear]) {
        //X月X日
        dateString = [BDMonthDayFormatter stringFromDate:self];
    } else {
        //X年X月X日
        dateString = [BDyyMMddFormatter stringFromDate:self];
    }
    return [dateString stringByReplacingOccurrencesOfString:@"-" withString:@"/"];
}

- (BOOL)_isThisYear {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    int unit = NSCalendarUnitYear;
    // 1.获得当前时间的年月日
    NSDateComponents *nowCmps = [calendar components:unit fromDate:[NSDate date]];
    // 2.获得self的年月日
    NSDateComponents *selfCmps = [calendar components:unit fromDate:self];
    return nowCmps.year == selfCmps.year;
}

- (NSInteger)dayPassedFromDate:(NSDate *)fromDate {
    if ([self timeIntervalSinceDate:fromDate] >= 0) {
        NSInteger dayPassedFromDate = 0;

        NSArray *fromArr = [[BDyyyyMMddFormatter stringFromDate:fromDate] componentsSeparatedByString:@"-"];
        NSArray *toArr = [[BDyyyyMMddFormatter stringFromDate:self] componentsSeparatedByString:@"-"];

        if ([toArr[0] integerValue] > [fromArr[0] integerValue]) {
            //跨年，则一定是今年1月与去年12月的比较
            dayPassedFromDate = 31 - [fromArr[2] integerValue] + [toArr[2] integerValue]; //31表示12月的天数
        } else {
            //同一年
            if ([toArr[1] integerValue] > [fromArr[1] integerValue]) {
                //跨月
                BOOL isLeapYear = [NSDate isLeapYear:[toArr[0] integerValue]];
                NSArray *daysOfMonth = isLeapYear ? [leapYearString componentsSeparatedByString:@"-"] : [nonLeapYearString componentsSeparatedByString:@"-"];

                NSInteger dayOfTargetMonth = [[daysOfMonth objectAtIndex:[fromArr[1] integerValue] - 1] integerValue];
                NSInteger dayOfOneDate = [toArr[2] integerValue];
                NSInteger dayOfAnotherDate = [fromArr[2] integerValue];

                dayPassedFromDate = dayOfTargetMonth - dayOfAnotherDate + dayOfOneDate;
            } else {
                //同一个月
                dayPassedFromDate = [toArr[2] integerValue] - [fromArr[2] integerValue];
            }
        }
        return dayPassedFromDate;
    } else {
        return -[fromDate dayPassedFromDate:self];
    }
}

+ (BOOL)isLeapYear:(NSInteger)year {
    if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {
        return YES;
    } else {
        return NO;
    }
    return NO;
}

- (NSString *)dateFormateForStandardDate {
   return [[BDyyyyMMddFormatter stringFromDate:self] stringByReplacingOccurrencesOfString:@"-" withString:@"/"];
}

+ (NSString *)durationStringFromTimeInterval:(NSTimeInterval)timeInterval {
    NSString *timeLimitString;
    if (timeInterval < 60*60) { // < 1 小时，显示为：* 分钟
        timeLimitString = [NSString stringWithFormat:BDUIString(HISTR_xf_minutes), floor(timeInterval/60)];
    } else if (timeInterval < 72*60*60) { // 1～72小时，显示为：* 小时
        timeLimitString = [NSString stringWithFormat:BDUIString(HISTR_xf_hours), floor(timeInterval/(60*60))];
    } else { //  > 72小时，显示为：* 天
        timeLimitString = [NSString stringWithFormat:BDUIString(HISTR_xf_days), floor(timeInterval/(24*60*60))];
    }
    return timeLimitString;
}

//计算两个时间点之间的天数
+ (NSUInteger)durationdaysWithStart:(long long)start end:(long long)end {
    NSTimeZone *locTimeZone = [NSTimeZone localTimeZone]; //本地时区
    NSInteger secondsFromGMT = locTimeZone.secondsFromGMT;
    
    long long secondsInOneDay = 86400;
    long long durationDays = 1;
    long long startZero = start - start % secondsInOneDay - secondsFromGMT; //开始时间本地时区零时
    long long endZero = end - end % secondsInOneDay - secondsFromGMT; //结束时间本地时区零时
    if ((start % secondsInOneDay) + secondsFromGMT == secondsInOneDay) {
        startZero = start;
    }
    if ((end % secondsInOneDay) + secondsFromGMT == secondsInOneDay) {
        endZero = end;
    }

    NSDate *startDate = [NSDate dateWithTimeIntervalSince1970:start];
    NSDate *endDate = [NSDate dateWithTimeIntervalSince1970:end - 1]; //24:00为下一日00：00，故减去1s

    if (startDate.year == endDate.year && startDate.month == endDate.month && startDate.day != endDate.day) {
        durationDays = endDate.day - startDate.day + 1;
    } else if (end - start > secondsInOneDay) {
        durationDays = (endZero - startZero) / secondsInOneDay + ((startZero == start && endZero == end) ? 0 : 1);
    }

    return durationDays;
}

+ (NSDate *)longlongTimeAddMonthConversionToDate:(long long)startTime monthNumber:(int)monthNumber{
    NSCalendar *calendar = [NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *components = [calendar components:NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay fromDate:[NSDate dateWithTimeIntervalSince1970:startTime]];
    components.month += monthNumber;
    NSDate *nowTime = [calendar dateFromComponents:components];
    return nowTime;
}

+ (NSDateComponents *)durationDateComponentsWithStart:(long long)start end:(long long)end {
    NSDate *startDate = [NSDate dateWithTimeIntervalSince1970:start];
    NSDate *endDate = [NSDate dateWithTimeIntervalSince1970:end - 1];
    NSCalendar *calendar = [NSCalendar calendarWithIdentifier:NSCalendarIdentifierGregorian];
    NSCalendarUnit unit1 = NSCalendarUnitDay | NSCalendarUnitMonth | NSCalendarUnitYear;//同时比较天数、月份差异
      //比较的结果是NSDateComponents类对象
    NSDateComponents *delta1 = [calendar components:unit1 fromDate:startDate toDate:endDate options:0];
    
    return delta1;
}

@end
